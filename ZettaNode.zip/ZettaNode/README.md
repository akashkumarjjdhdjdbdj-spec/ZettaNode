# ZettaNode Custom VPS Control
**Credit:** made by tyrkrox_tech

## Included
- `install.sh` — installs the web panel (systemd service), Docker, KVM/libvirt and the Ubuntu 24.04 / 22.04 / Debian 12 cloud images.
- `bot.sh` — installs the Discord bot, asks for token/role/API details, optionally installs it as a systemd service.
- `panel/` — Flask panel (Nebula Glass theme: Nebula / Aurora / Light).
- `bot.py` — role-gated Discord bot.

## Deploy
Use a dedicated Ubuntu 24.04 server (KVM-capable if you want KVM VPS).
```bash
cd ZettaNode
sudo bash install.sh     # panel on http://SERVER_IP:8888
sudo bash bot.sh         # discord bot (reads the API secret from panel/.env automatically)
```
Bot invite scopes: `bot` + `applications.commands`.
Open firewall ports: **8888** (panel) and **20000-29999** (Docker VPS SSH).

## Panel features
- Themes: Nebula, Aurora, Light (saved in your browser)
- Dashboard stats, search, live status **Sync**, show/copy password, copy SSH command
- Start / Stop / Restart / Suspend / Unsuspend / Reinstall / Delete / **New password**
- Per-user VPS limit (`MAX_VPS_PER_USER` in `panel/.env`, default 3; admin unlimited)
- Profile page: change password, **link Discord**
- Admin page: all users and all VPS
- Security: CSRF protection, login rate-limit, secure session cookies, API secret compared in constant time

## Bot commands
| Command | What it does |
|---|---|
| `/create` | Create Docker/KVM VPS (node, OS, username, RAM, CPU, disk) |
| `/list` | Your VPS with live status |
| `/info` | Login details (password is a spoiler) |
| `/manage` | start / stop / restart / suspend / unsuspend / reinstall / delete (confirm button for destructive ones) |
| `/resetpass` | New password (Docker VPS) |
| `/link` | Link Discord to your panel account (code from panel → Profile) |
| `/help` | Command list |

VPS created in Discord belong to the Discord ID. After `/link`, they also appear in the linked panel account.

## Supported OS (17)
Ubuntu 24.04 / 22.04 / 20.04 · Debian 13 / 12 / 11 · AlmaLinux 9 / 8 · Rocky Linux 9 / 8 · CentOS Stream 9 · Arch Linux ·
Fedora 42, Alpine, openSUSE Leap 15.6, openSUSE Tumbleweed, Kali (**Docker only**).
- KVM images (other than the 3 pre-downloaded Ubuntu/Debian ones) are downloaded automatically the first time that OS is used.
- AlmaLinux / Rocky / CentOS KVM images need at least 10 GB disk (checked automatically).
- Windows / macOS are not included: they need licensed ISO images and a different setup (not cloud-init based).

## Notes
- Hostname is always `ZettaNode-freevps-` + 7 random characters.
- Docker VPS: SSH on a fixed host port (20000-29999). First boot installs OpenSSH, so wait ~1 minute.
- KVM VPS: sits on libvirt's NAT network; the panel shows the internal IP. For public access add your own port-forward/bridge.
- Free/Paid are labels on this single host (no remote node agents yet).
- Docker disk quota is not enforced (depends on storage driver). KVM CPU is rounded up to whole vCPUs.
- Railway cannot host KVM (`/dev/kvm` missing). Run provisioning on a real Ubuntu server.
- Starter project: add HTTPS (reverse proxy, then set `COOKIE_SECURE=1` in panel/.env), backups, quotas and abuse controls before public use. Never expose the Docker socket.
