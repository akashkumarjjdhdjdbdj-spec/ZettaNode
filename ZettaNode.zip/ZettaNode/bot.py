import os, aiohttp, discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)
CREATE_ROLE_ID = int(os.getenv("CREATE_ROLE_ID", "0") or 0)
PANEL_API = os.getenv("PANEL_API", "http://127.0.0.1:8888").rstrip("/")
PANEL_URL = os.getenv("PANEL_URL", "").rstrip("/")
API_SECRET = os.getenv("ZETTA_API_SECRET", "")
COLOR = 0x8B5CF6  # matches the panel's Nebula theme

if not TOKEN or not CREATE_ROLE_ID or not API_SECRET:
    raise SystemExit("Set DISCORD_TOKEN, CREATE_ROLE_ID and ZETTA_API_SECRET in .env")


# (label, value). Discord allows max 25 choices.
OS_LIST = [
    ("Ubuntu 24.04 LTS", "ubuntu-24.04"), ("Ubuntu 22.04 LTS", "ubuntu-22.04"), ("Ubuntu 20.04 LTS", "ubuntu-20.04"),
    ("Debian 13", "debian-13"), ("Debian 12", "debian-12"), ("Debian 11", "debian-11"),
    ("AlmaLinux 9", "almalinux-9"), ("AlmaLinux 8", "almalinux-8"),
    ("Rocky Linux 9", "rocky-9"), ("Rocky Linux 8", "rocky-8"), ("CentOS Stream 9", "centos-stream-9"),
    ("Arch Linux", "archlinux"), ("Fedora 42", "fedora-42"), ("Alpine Linux", "alpine"),
    ("openSUSE Leap 15.6", "opensuse-leap"), ("openSUSE Tumbleweed", "opensuse-tumbleweed"),
    ("Kali Linux", "kali"),
]
OS_CHOICES = [app_commands.Choice(name=n, value=v) for n, v in OS_LIST]


class ZettaBot(commands.Bot):
    async def setup_hook(self):
        if GUILD_ID:
            g = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=g)
            await self.tree.sync(guild=g)
        else:
            await self.tree.sync()


bot = ZettaBot(command_prefix=commands.when_mentioned, intents=discord.Intents.default())


def permitted(interaction: discord.Interaction) -> bool:
    return isinstance(interaction.user, discord.Member) and any(r.id == CREATE_ROLE_ID for r in interaction.user.roles)


async def api(path, payload, timeout=900):
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
        async with s.post(PANEL_API + path, json=payload, headers={"X-Zetta-Secret": API_SECRET}) as r:
            try:
                data = await r.json(content_type=None)
            except Exception:
                data = {}
            if r.status >= 400:
                raise RuntimeError(data.get("error", f"Panel API returned status {r.status}"))
            return data


def embed(title, desc="", color=COLOR):
    e = discord.Embed(title=title, description=desc, color=color)
    e.set_footer(text="ZettaNode Custom VPS Control · made by tyrkrox_tech")
    return e


async def no_role(interaction):
    await interaction.response.send_message(embed=embed("❌ Access denied", "You need the ZettaNode role to use this command.", 0xFB7185), ephemeral=True)


def vps_embed(v, title="🖥 VPS"):
    e = embed(title)
    e.add_field(name="Hostname", value=f"`{v['name']}`", inline=False)
    e.add_field(name="Status", value=f"`{v['status']}`")
    e.add_field(name="Node · Type", value=f"`{v['node']}` · `{v['kind_label']}`")
    e.add_field(name="OS", value=f"`{v['os']}`")
    e.add_field(name="Resources", value=f"`{v['ram']} GB` RAM · `{v['cpu']}` CPU · `{v['disk']} GB` disk", inline=False)
    e.add_field(name="Login", value=f"User: `{v['username']}`\nPassword: ||`{v['password']}`||\nSSH: `{v['ssh']}`" + (f"\nTailscale: `{v['ssh_ts']}`" if v.get("ssh_ts") else ""), inline=False)
    return e


async def host_autocomplete(interaction: discord.Interaction, current: str):
    try:
        data = await api("/api/bot/list", {"owner": str(interaction.user.id)}, timeout=2.5)
    except Exception:
        return []
    return [app_commands.Choice(name=f"{v['name']} ({v['status']})", value=v["name"])
            for v in data.get("vps", []) if current.lower() in v["name"].lower()][:25]


class Confirm(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=30)
        self.user_id, self.ok = user_id, None

    async def interaction_check(self, interaction):
        return interaction.user.id == self.user_id

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def yes(self, interaction, button):
        self.ok = True
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def no(self, interaction, button):
        self.ok = False
        await interaction.response.defer()
        self.stop()


@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.Game(name="ZettaNode · /help"))
    print(f"{bot.user} online — ZettaNode Custom VPS Control")


@bot.tree.command(name="help", description="Show ZettaNode bot commands")
async def help_cmd(interaction: discord.Interaction):
    e = embed("ZettaNode · Commands")
    e.add_field(name="/create", value="Create a Docker or KVM-style VPS", inline=False)
    e.add_field(name="/list", value="Show your VPS", inline=False)
    e.add_field(name="/info", value="Login details for one VPS", inline=False)
    e.add_field(name="/manage", value="Start, stop, restart, suspend, reinstall or delete a VPS", inline=False)
    e.add_field(name="/resetpass", value="New password", inline=False)
    e.add_field(name="/link", value="Link Discord to your panel account", inline=False)
    if PANEL_URL:
        e.add_field(name="Panel", value=PANEL_URL, inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)


@bot.tree.command(name="create", description="Create a ZettaNode VPS (Docker or KVM-style)")
@app_commands.describe(node="Free Node or Paid Node", kind="Docker, or KVM-style (Docker that reports KVM inside - not real KVM)", os="Operating system",
                       username="Linux VPS username", ram="RAM in GB", cpu="CPU cores", disk="Disk in GB")
@app_commands.choices(
    node=[app_commands.Choice(name="Free Node", value="free"), app_commands.Choice(name="Paid Node", value="paid")],
    kind=[app_commands.Choice(name="Docker VPS", value="docker"),
          app_commands.Choice(name="KVM-style VPS (Docker, not real KVM)", value="kvm")],
    os=OS_CHOICES)
async def create(interaction: discord.Interaction, node: app_commands.Choice[str], kind: app_commands.Choice[str],
                 os: app_commands.Choice[str], username: app_commands.Range[str, 2, 24],
                 ram: app_commands.Range[int, 1, 32], cpu: app_commands.Range[float, 0.25, 16],
                 disk: app_commands.Range[int, 5, 200]):
    if not permitted(interaction):
        return await no_role(interaction)
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        r = await api("/api/bot/create", {"owner": str(interaction.user.id), "node": node.value, "kind": kind.value,
                                          "os": os.value, "username": username, "ram": ram, "cpu": cpu, "disk": disk})
        e = embed("✅ VPS created")
        e.add_field(name="Hostname", value=f"`{r['hostname']}`", inline=False)
        e.add_field(name="Node · Type", value=f"`{node.name}` · `{r['kind_label']}`")
        e.add_field(name="OS", value=f"`{os.name}`")
        e.add_field(name="Resources", value=f"`{ram} GB` · `{cpu}` CPU · `{disk} GB`", inline=False)
        e.add_field(name="Login", value=f"User: `{r['username']}`\nPassword: ||`{r['password']}`||\nSSH: `{r['ssh']}`" + (f"\nTailscale: `{r['ssh_ts']}`" if r.get("ssh_ts") else ""), inline=False)
        e.add_field(name="Note", value="First boot installs SSH — wait ~1 minute before connecting.", inline=False)
        if r.get("notes"):
            e.add_field(name="⚠ Host warning", value="\n".join(r["notes"])[:1000], inline=False)
        await interaction.followup.send(embed=e, ephemeral=True)
    except Exception as ex:
        await interaction.followup.send(embed=embed("❌ Create failed", f"`{str(ex)[:1500]}`", 0xFB7185), ephemeral=True)


@bot.tree.command(name="list", description="List your ZettaNode VPS")
async def list_cmd(interaction: discord.Interaction):
    if not permitted(interaction):
        return await no_role(interaction)
    await interaction.response.defer(ephemeral=True)
    try:
        vps = (await api("/api/bot/list", {"owner": str(interaction.user.id), "sync": True}, timeout=60))["vps"]
    except Exception as ex:
        return await interaction.followup.send(embed=embed("❌ Error", f"`{str(ex)[:1500]}`", 0xFB7185), ephemeral=True)
    if not vps:
        return await interaction.followup.send(embed=embed("No VPS yet", "Use `/create` to make one."), ephemeral=True)
    icon = {"running": "🟢", "suspended": "🟡"}
    lines = [f"{icon.get(v['status'], '🔴')} `{v['name']}` · {'KVM-style' if v['kind'] == 'kvm' else 'Docker'} · {v['ram']}GB/{v['cpu']}CPU/{v['disk']}GB" for v in vps]
    await interaction.followup.send(embed=embed(f"🖥 Your VPS ({len(vps)})", "\n".join(lines)), ephemeral=True)


@bot.tree.command(name="info", description="Show login details of one VPS")
@app_commands.describe(hostname="Pick your VPS")
@app_commands.autocomplete(hostname=host_autocomplete)
async def info(interaction: discord.Interaction, hostname: str):
    if not permitted(interaction):
        return await no_role(interaction)
    await interaction.response.defer(ephemeral=True)
    try:
        v = await api("/api/bot/info", {"owner": str(interaction.user.id), "hostname": hostname}, timeout=60)
        await interaction.followup.send(embed=vps_embed(v), ephemeral=True)
    except Exception as ex:
        await interaction.followup.send(embed=embed("❌ Error", f"`{str(ex)[:1500]}`", 0xFB7185), ephemeral=True)


@bot.tree.command(name="manage", description="Start, stop, restart, suspend, reinstall or delete a VPS")
@app_commands.describe(hostname="Pick your VPS", action="What to do")
@app_commands.autocomplete(hostname=host_autocomplete)
@app_commands.choices(action=[app_commands.Choice(name=n, value=v) for n, v in [
    ("▶ Start", "start"), ("■ Stop", "stop"), ("↻ Restart", "restart"), ("⏸ Suspend", "suspend"),
    ("⏯ Unsuspend", "unsuspend"), ("♻ Reinstall (erases data)", "reinstall"), ("🗑 Delete (permanent)", "delete")]])
async def manage(interaction: discord.Interaction, hostname: str, action: app_commands.Choice[str]):
    if not permitted(interaction):
        return await no_role(interaction)
    if action.value in ("reinstall", "delete"):
        view = Confirm(interaction.user.id)
        await interaction.response.send_message(
            embed=embed("⚠ Confirm", f"{action.name} `{hostname}`? This cannot be undone.", 0xFBBF24), view=view, ephemeral=True)
        await view.wait()
        if not view.ok:
            return await interaction.edit_original_response(embed=embed("Cancelled"), view=None)
        await interaction.edit_original_response(embed=embed("⏳ Working…", f"{action.name} `{hostname}`"), view=None)
        send = interaction.edit_original_response
    else:
        await interaction.response.defer(ephemeral=True, thinking=True)
        send = interaction.edit_original_response
    try:
        await api("/api/bot/action", {"owner": str(interaction.user.id), "hostname": hostname, "action": action.value})
        await send(embed=embed("✅ Done", f"{action.name} completed for `{hostname}`."), view=None)
    except Exception as ex:
        await send(embed=embed("❌ Failed", f"`{str(ex)[:1500]}`", 0xFB7185), view=None)


@bot.tree.command(name="resetpass", description="Generate a new password for a VPS")
@app_commands.describe(hostname="Pick your VPS")
@app_commands.autocomplete(hostname=host_autocomplete)
async def resetpass(interaction: discord.Interaction, hostname: str):
    if not permitted(interaction):
        return await no_role(interaction)
    await interaction.response.defer(ephemeral=True)
    try:
        r = await api("/api/bot/action", {"owner": str(interaction.user.id), "hostname": hostname, "action": "resetpass"}, timeout=60)
        await interaction.followup.send(embed=embed("🔑 New password", f"`{hostname}`\nPassword: ||`{r['password']}`||"), ephemeral=True)
    except Exception as ex:
        await interaction.followup.send(embed=embed("❌ Failed", f"`{str(ex)[:1500]}`", 0xFB7185), ephemeral=True)


@bot.tree.command(name="link", description="Link Discord to your panel account (code from panel → Profile)")
@app_commands.describe(code="8-character code from the panel Profile page")
async def link(interaction: discord.Interaction, code: str):
    await interaction.response.defer(ephemeral=True)
    try:
        r = await api("/api/bot/link", {"owner": str(interaction.user.id), "code": code}, timeout=30)
        await interaction.followup.send(embed=embed("🔗 Linked", f"Discord linked to panel user **{r['username']}**."), ephemeral=True)
    except Exception as ex:
        await interaction.followup.send(embed=embed("❌ Failed", f"`{str(ex)[:1500]}`", 0xFB7185), ephemeral=True)


if __name__ == "__main__":
    bot.run(TOKEN)
