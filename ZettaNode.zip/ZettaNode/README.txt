ZettaNode VPS Bot - Updated

Files:
- bot.py: updated bot source
- .env: configuration template
- zettanode_logo.jpg: ZettaNode logo

Setup:
1. Revoke the previously exposed Discord bot token in Discord Developer Portal and generate a new one.
2. Put the NEW token in DISCORD_TOKEN in .env.
3. Set YOUR_SERVER_IP to your node public IP.
4. MAIN_ADMIN_ID is already set to the Discord user ID supplied by the owner.
5. Install dependencies: pip install -U discord.py python-dotenv requests
6. Run: python bot.py

Commands:
cb?start <vps-id-or-container>
cb?stop <vps-id-or-container>
cb?status <vps-id-or-container>
cb?sshx <vps-id-or-container>  (alias: cb?ssh)
cb?password <vps-id-or-container> [new-password]
cb?backup <vps-id-or-container> (alias: cb?vps-backup)

VPS controls are owner-only; bot admins can control any VPS. No Discord VPS role ID is required.
Backups create an LXC snapshot on the same node; export/copy it off-node separately for disaster recovery.
