import os, re, math, hmac, socket, sqlite3, subprocess, secrets, string, threading, time, shutil
from collections import defaultdict, deque
from contextlib import contextmanager
from pathlib import Path
from functools import wraps
from flask import (Flask, request, redirect, url_for, session, render_template,
                   flash, abort)
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = Path(__file__).resolve().parent


def _load_env_file():
    """Load panel/.env when running manually (systemd already injects it)."""
    f = APP_DIR / ".env"
    if not f.exists():
        return
    for line in f.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip("'\""))


_load_env_file()

DB = APP_DIR / "zettanode.db"
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_urlsafe(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1")
API_SECRET = os.environ.get("ZETTA_API_SECRET", "")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "")
PUBLIC_HOST = os.environ.get("PUBLIC_HOST", "YOUR_SERVER_IP")
MAX_VPS_PER_USER = int(os.environ.get("MAX_VPS_PER_USER", "3"))
PORT_RANGE = (20000, 29999)
LOCK = threading.Lock()

# group = section in the panel dropdown; docker = image used for the VPS
OS_OPTIONS = {
    "ubuntu-24.04": {"label": "Ubuntu 24.04 LTS", "group": "Ubuntu", "docker": "ubuntu:24.04"},
    "ubuntu-22.04": {"label": "Ubuntu 22.04 LTS", "group": "Ubuntu", "docker": "ubuntu:22.04"},
    "ubuntu-20.04": {"label": "Ubuntu 20.04 LTS", "group": "Ubuntu", "docker": "ubuntu:20.04"},
    "debian-13": {"label": "Debian 13 (Trixie)", "group": "Debian", "docker": "debian:13"},
    "debian-12": {"label": "Debian 12 (Bookworm)", "group": "Debian", "docker": "debian:12"},
    "debian-11": {"label": "Debian 11 (Bullseye)", "group": "Debian", "docker": "debian:11"},
    "almalinux-9": {"label": "AlmaLinux 9", "group": "RHEL family", "docker": "almalinux:9"},
    "almalinux-8": {"label": "AlmaLinux 8", "group": "RHEL family", "docker": "almalinux:8"},
    "rocky-9": {"label": "Rocky Linux 9", "group": "RHEL family", "docker": "rockylinux:9"},
    "rocky-8": {"label": "Rocky Linux 8", "group": "RHEL family", "docker": "rockylinux:8"},
    "centos-stream-9": {"label": "CentOS Stream 9", "group": "RHEL family", "docker": "quay.io/centos/centos:stream9"},
    "fedora-42": {"label": "Fedora 42", "group": "Other", "docker": "fedora:42"},
    "archlinux": {"label": "Arch Linux", "group": "Other", "docker": "archlinux:latest"},
    "alpine": {"label": "Alpine Linux", "group": "Other", "docker": "alpine:latest"},
    "opensuse-leap": {"label": "openSUSE Leap 15.6", "group": "Other", "docker": "opensuse/leap:15.6"},
    "opensuse-tumbleweed": {"label": "openSUSE Tumbleweed", "group": "Other", "docker": "opensuse/tumbleweed"},
    "kali": {"label": "Kali Linux", "group": "Other", "docker": "kalilinux/kali-rolling"},
}
# "kvm" = KVM-style: still a Docker container, but tools like systemd-detect-virt / lscpu report KVM. NOT real KVM.
KIND_LABEL = {"docker": "Docker VPS", "kvm": "KVM-style VPS (Docker container)"}
ACTIONS = {"start", "stop", "restart", "reinstall", "delete", "suspend", "unsuspend", "resetpass"}
RESERVED_USERS = {"root", "daemon", "bin", "sys", "sync", "games", "man", "lp", "mail", "news",
                  "uucp", "proxy", "www-data", "backup", "list", "irc", "nobody", "sshd"}


# ───────────────────────── database ─────────────────────────
@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _add_col(c, table, col, ddl):
    cols = {r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}
    if col not in cols:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")


def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user')""")
        c.execute("""CREATE TABLE IF NOT EXISTS vps(
            id INTEGER PRIMARY KEY, owner TEXT NOT NULL, name TEXT UNIQUE NOT NULL,
            kind TEXT NOT NULL, ram INTEGER NOT NULL, cpu REAL NOT NULL,
            disk INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'creating',
            password TEXT NOT NULL, node TEXT NOT NULL DEFAULT 'free',
            guest_username TEXT NOT NULL DEFAULT 'ubuntu',
            os_image TEXT NOT NULL DEFAULT 'ubuntu-24.04',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        _add_col(c, "vps", "node", "TEXT NOT NULL DEFAULT 'free'")
        _add_col(c, "vps", "guest_username", "TEXT NOT NULL DEFAULT 'ubuntu'")
        _add_col(c, "vps", "os_image", "TEXT NOT NULL DEFAULT 'ubuntu-24.04'")
        _add_col(c, "vps", "ssh_port", "INTEGER")
        _add_col(c, "vps", "ip", "TEXT")
        _add_col(c, "users", "discord_id", "TEXT")
        _add_col(c, "users", "link_code", "TEXT")
        _add_col(c, "users", "link_expires", "INTEGER")
        if ADMIN_PASS:
            c.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES(?,?,?)",
                      (ADMIN_USER, generate_password_hash(ADMIN_PASS), "admin"))


# ───────────────────────── helpers ─────────────────────────
def run(cmd, timeout=900, input=None):
    try:
        return subprocess.run(cmd, check=True, text=True, capture_output=True,
                              timeout=timeout, input=input)
    except subprocess.CalledProcessError as e:
        msg = (e.stderr or e.stdout or "").strip().splitlines()
        raise RuntimeError(f"{cmd[0]} failed: {' | '.join(msg[-3:]) or e.returncode}") from None
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{cmd[0]} timed out") from None
    except FileNotFoundError:
        raise RuntimeError(f"'{cmd[0]}' is not installed on this host") from None


def quiet(cmd, timeout=60):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception:
        return None


def hostname():
    chars = string.ascii_lowercase + string.digits
    with db() as c:
        while True:
            name = "ZettaNode-freevps-" + "".join(secrets.choice(chars) for _ in range(7))
            if not c.execute("SELECT 1 FROM vps WHERE name=?", (name,)).fetchone():
                return name


def clean_username(value):
    value = (value or "").strip().lower()
    if value in RESERVED_USERS or not re.fullmatch(r"[a-z_][a-z0-9_-]{1,23}", value):
        raise ValueError("VPS username: 2-24 chars, start with a letter/underscore, only a-z 0-9 _ - "
                         "(reserved names like root are not allowed).")
    return value


def parse_resources(ram, cpu, disk):
    try:
        ram, cpu, disk = int(ram), float(cpu), int(disk)
    except (TypeError, ValueError):
        raise ValueError("RAM, CPU and disk must be numbers.") from None
    if not (1 <= ram <= 32 and 0.25 <= cpu <= 16 and 5 <= disk <= 200):
        raise ValueError("Limits: RAM 1-32 GB, CPU 0.25-16, Disk 5-200 GB.")
    return ram, cpu, disk


def free_port():
    with db() as c:
        used = {r[0] for r in c.execute("SELECT ssh_port FROM vps WHERE ssh_port IS NOT NULL")}
    for _ in range(200):
        p = secrets.randbelow(PORT_RANGE[1] - PORT_RANGE[0]) + PORT_RANGE[0]
        if p in used:
            continue
        with socket.socket() as s:
            try:
                s.bind(("0.0.0.0", p))
            except OSError:
                continue
        return p
    raise RuntimeError("No free SSH port available.")


# ───────────────────────── provisioning ─────────────────────────
DOCKER_BOOT = r'''set -e
if [ ! -f /var/lib/.zetta-ready ]; then
  export DEBIAN_FRONTEND=noninteractive
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq
    apt-get install -y -qq openssh-server sudo passwd ca-certificates >/dev/null
    apt-get install -y -qq curl nano >/dev/null 2>&1 || true
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y -q openssh-server sudo passwd shadow-utils
    dnf install -y -q nano curl >/dev/null 2>&1 || true
  elif command -v yum >/dev/null 2>&1; then
    yum install -y -q openssh-server sudo passwd shadow-utils
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache openssh sudo shadow bash
    apk add --no-cache nano curl >/dev/null 2>&1 || true
  elif command -v pacman >/dev/null 2>&1; then
    pacman -Sy --noconfirm --needed openssh sudo >/dev/null
  elif command -v zypper >/dev/null 2>&1; then
    zypper -n install --no-recommends openssh sudo shadow
  else
    echo "Unsupported package manager" >&2; exit 1
  fi
  id "$ZUSER" >/dev/null 2>&1 || useradd -m -s /bin/bash "$ZUSER"
  mkdir -p /etc/sudoers.d
  grep -q '^[#@]includedir /etc/sudoers.d' /etc/sudoers 2>/dev/null || echo '@includedir /etc/sudoers.d' >> /etc/sudoers
  echo "$ZUSER ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/90-zetta
  chmod 440 /etc/sudoers.d/90-zetta
  echo "$ZUSER:$ZPASS" | chpasswd
  if [ "$ZKVM" = "1" ]; then
    mkdir -p /usr/local/bin
    cat > /usr/local/bin/systemd-detect-virt <<'ZW'
#!/bin/sh
for a in "$@"; do
  case "$a" in
    -c|--container) echo none; exit 1;;
    -q|--quiet) exit 0;;
  esac
done
echo kvm
ZW
    printf '#!/bin/sh\necho kvm\n' > /usr/local/bin/virt-what
    if [ -x /usr/bin/lscpu ] || [ -x /bin/lscpu ]; then
      cat > /usr/local/bin/lscpu <<'ZW'
#!/bin/sh
REAL=/usr/bin/lscpu; [ -x "$REAL" ] || REAL=/bin/lscpu
if [ $# -ne 0 ]; then exec "$REAL" "$@"; fi
"$REAL" | grep -v '^Hypervisor vendor:' | grep -v '^Virtualization type:'
echo "Hypervisor vendor:                    KVM"
echo "Virtualization type:                  full"
ZW
    fi
    chmod 755 /usr/local/bin/systemd-detect-virt /usr/local/bin/virt-what /usr/local/bin/lscpu 2>/dev/null || true
  fi
  ssh-keygen -A
  [ -f /etc/ssh/sshd_config ] || cp /usr/etc/ssh/sshd_config /etc/ssh/sshd_config 2>/dev/null || true
  sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  touch /var/lib/.zetta-ready
fi
if [ -f /opt/zetta/pterodactyl.sh ]; then
  ZHOME="$(getent passwd "$ZUSER" | cut -d: -f6)"; [ -n "$ZHOME" ] || ZHOME="/home/$ZUSER"
  if [ -d "$ZHOME" ] && [ ! -f "$ZHOME/pterodactyl.sh" ]; then
    cp /opt/zetta/pterodactyl.sh "$ZHOME/pterodactyl.sh"
    chown "$ZUSER" "$ZHOME/pterodactyl.sh" 2>/dev/null || true
    chmod 755 "$ZHOME/pterodactyl.sh"
  fi
fi
mkdir -p /run/sshd /var/run/sshd
exec "$(command -v sshd || echo /usr/sbin/sshd)" -D -e
'''


PTERO_SCRIPT = APP_DIR.parent / "pterodactyl.sh"   # copied into every new VPS (free + paid)

LXCFS = Path("/var/lib/lxcfs")
LXCFS_FILES = [("proc/cpuinfo", "/proc/cpuinfo"), ("proc/diskstats", "/proc/diskstats"),
               ("proc/meminfo", "/proc/meminfo"), ("proc/stat", "/proc/stat"),
               ("proc/swaps", "/proc/swaps"), ("proc/uptime", "/proc/uptime"),
               ("sys/devices/system/cpu/online", "/sys/devices/system/cpu/online")]


def lxcfs_flags():
    """lxcfs makes free/top/nproc/lscpu inside the container show the container's limits, not the host's."""
    if not (LXCFS / "proc/meminfo").exists():
        return None
    out = []
    for src, dst in LXCFS_FILES:
        if (LXCFS / src).exists():
            out += ["-v", f"{LXCFS / src}:{dst}:rw"]
    return out


def cpuset_for(cores):
    """Pin the container to `cores` host cores so nproc/lscpu show exactly that many."""
    host = os.cpu_count() or 1
    if cores > host:
        raise ValueError(f"This host has only {host} CPU cores - choose {host} or fewer.")
    with db() as c:
        used = sum(math.ceil(r[0]) for r in c.execute("SELECT cpu FROM vps WHERE kind='docker'"))
    start = used % host
    return ",".join(str((start + i) % host) for i in range(cores))


def create_docker(name, ram, cpu, disk, password, username, os_image, port=None, kvm_style=False):
    """Returns (ssh_port, notes). notes = warnings about limits the host could not enforce/show."""
    image = OS_OPTIONS[os_image]["docker"]
    port = port or free_port()
    notes = []
    run(["docker", "pull", image])
    base = ["docker", "run", "-d", "--name", name, "--hostname", name,
            "--memory", f"{ram}g", "--memory-swap", f"{ram}g",
            "--cpus", str(cpu), "--cpuset-cpus", cpuset_for(max(1, math.ceil(cpu))),
            "--pids-limit", "512", "--restart", "unless-stopped", "-p", f"{port}:22",
            "-e", f"ZUSER={username}", "-e", f"ZPASS={password}", "-e", f"ZKVM={1 if kvm_style else 0}"]
    if PTERO_SCRIPT.is_file():
        base += ["-v", f"{PTERO_SCRIPT}:/opt/zetta/pterodactyl.sh:ro"]
    else:
        notes.append(f"{PTERO_SCRIPT} not found: pterodactyl.sh was not added to this VPS.")
    lx = lxcfs_flags()
    if lx is None:
        lx = []
        notes.append("lxcfs is not installed on the host: RAM/CPU are limited, but free/nproc inside the VPS "
                     "still show the host's values. Run: apt install lxcfs")
    tail = [image, "sh", "-c", DOCKER_BOOT]
    try:
        run(base + ["--storage-opt", f"size={disk}G"] + lx + tail)
    except RuntimeError as e:
        if "storage-opt" not in str(e) and "quota" not in str(e).lower():
            raise
        quiet(["docker", "rm", "-f", name])
        run(base + lx + tail)
        notes.append("Disk quota is not supported by the host's Docker storage (needs overlay2 on XFS with pquota): "
                     "df inside the VPS shows the host disk. Re-run install.sh and enable the disk-quota option.")
    return port, notes


def cleanup(name):
    """Best-effort removal of a half-created container."""
    quiet(["docker", "rm", "-f", name])


def owned_count(owner):
    with db() as c:
        return c.execute("SELECT COUNT(*) FROM vps WHERE owner=?", (owner,)).fetchone()[0]


def create_vps(owner, kind, ram, cpu, disk, node, username, os_image, unlimited=False):
    username = clean_username(username)
    ram, cpu, disk = parse_resources(ram, cpu, disk)
    if kind not in KIND_LABEL:
        raise ValueError("Unknown VPS type.")
    if node not in ("free", "paid"):
        raise ValueError("Choose Free Node or Paid Node.")
    if os_image not in OS_OPTIONS:
        raise ValueError("Unsupported operating system.")
    with LOCK:
        if not unlimited and owned_count(owner) >= MAX_VPS_PER_USER:
            raise ValueError(f"VPS limit reached ({MAX_VPS_PER_USER} per user). Delete one first.")
        name = hostname()
        password = secrets.token_urlsafe(12)
        port = ip = None
        notes = []
        try:
            port, notes = create_docker(name, ram, cpu, disk, password, username, os_image, kvm_style=(kind == 'kvm'))
        except Exception:
            cleanup(name)
            raise
        with db() as c:
            c.execute("""INSERT INTO vps(owner,name,kind,ram,cpu,disk,status,password,node,
                                         guest_username,os_image,ssh_port,ip)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (owner, name, kind, ram, cpu, disk, "running", password, node,
                       username, os_image, port, ip))
    return {"hostname": name, "username": username, "password": password, "status": "running",
            "node": node, "os": os_image, "kind": kind, "ssh_port": port, "notes": notes,
            "ssh": ssh_cmd({"guest_username": username, "ssh_port": port}),
            "ssh_ts": ssh_ts_cmd({"guest_username": username, "ssh_port": port}),
            "kind_label": KIND_LABEL[kind]}


# ───────────────────────── SSHX (browser terminal link) ─────────────────────────
SSHX_SCRIPT = r'''LOG=/tmp/sshx.log; PIDF=/tmp/sshx.pid
link() { tr -d '\033' < "$LOG" 2>/dev/null | grep -o 'https://sshx\.io/s/[A-Za-z0-9#_=./-]*' | tail -n 1; }
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null && [ -n "$(link)" ]; then link; exit 0; fi
if ! command -v curl >/dev/null 2>&1; then
  S=""; [ "$(id -u)" = "0" ] || S="sudo -n"
  if command -v apt-get >/dev/null 2>&1; then $S apt-get update -qq >/dev/null 2>&1; $S apt-get install -y -qq curl ca-certificates >/dev/null 2>&1
  elif command -v apk >/dev/null 2>&1; then $S apk add --no-cache curl >/dev/null 2>&1
  elif command -v dnf >/dev/null 2>&1; then $S dnf install -y -q curl >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then $S yum install -y -q curl >/dev/null 2>&1
  elif command -v pacman >/dev/null 2>&1; then $S pacman -Sy --noconfirm --needed curl >/dev/null 2>&1
  elif command -v zypper >/dev/null 2>&1; then $S zypper -n install curl >/dev/null 2>&1
  fi
fi
command -v curl >/dev/null 2>&1 || { echo "curl is not available in this VPS (is it still booting?)" >&2; exit 3; }
rm -f "$LOG"
nohup sh -c 'curl -sSf https://sshx.io/get | sh -s run' > "$LOG" 2>&1 &
echo $! > "$PIDF"
i=0
while [ $i -lt 40 ]; do
  L="$(link)"; [ -n "$L" ] && { echo "$L"; exit 0; }
  sleep 1; i=$((i+1))
done
tail -n 3 "$LOG" >&2; exit 4
'''


def start_sshx(row):
    """Start (or reuse) an sshx session inside the VPS and return the share link."""
    if live_status(row) != "running":
        raise RuntimeError("Start the VPS first.")
    out = run(["docker", "exec", "-u", row["guest_username"], row["name"], "sh", "-c", SSHX_SCRIPT], timeout=90)
    m = re.search(r"https://sshx\.io/s/\S+", out.stdout)
    if not m:
        raise RuntimeError("sshx did not return a link.")
    return m.group(0)


_ts_cache = [0.0, None]


def ts_host():
    """Tailscale IPv4 of this host (TAILSCALE_HOST env overrides; otherwise asks the tailscale CLI, cached 30 s)."""
    env = os.environ.get("TAILSCALE_HOST", "").strip()
    if env:
        return env
    now = time.time()
    if now - _ts_cache[0] > 30:
        r = quiet(["tailscale", "ip", "-4"], 5)
        ip = (r.stdout.split() or [None])[0] if r is not None and r.returncode == 0 else None
        _ts_cache[:] = [now, ip]
    return _ts_cache[1]


def ssh_cmd(v):
    return f"ssh {v['guest_username']}@{PUBLIC_HOST} -p {v['ssh_port']}" if v["ssh_port"] else "SSH port pending"


def ssh_ts_cmd(v):
    host = ts_host()
    return f"ssh {v['guest_username']}@{host} -p {v['ssh_port']}" if host and v["ssh_port"] else None


def live_status(row):
    r = quiet(["docker", "inspect", "-f", "{{.State.Status}}", row["name"]], 10)
    if r is None:
        return row["status"]
    if r.returncode != 0:
        return "missing"
    state = "running" if r.stdout.strip() == "running" else "stopped"
    if state != "running" and row["status"] == "suspended":
        return "suspended"
    return state


def sync_rows(rows):
    with db() as c:
        for row in rows:
            c.execute("UPDATE vps SET status=? WHERE id=?", (live_status(row), row["id"]))


def control(row, action, new_password=None):
    name, port = row["name"], row["ssh_port"]
    if action in ("start", "unsuspend"): run(["docker", "start", name])
    elif action in ("stop", "suspend"): run(["docker", "stop", name])
    elif action == "restart": run(["docker", "restart", name])
    elif action == "delete": run(["docker", "rm", "-f", name])
    elif action == "reinstall":
        quiet(["docker", "rm", "-f", name])
        create_docker(name, row["ram"], row["cpu"], row["disk"], row["password"],
                      row["guest_username"], row["os_image"], port=port, kvm_style=(row["kind"] == "kvm"))
    elif action == "resetpass":
        run(["docker", "exec", "-i", name, "chpasswd"],
            input=f"{row['guest_username']}:{new_password}\n", timeout=30)
    status = {"delete": "deleted", "suspend": "suspended", "stop": "stopped"}.get(action, "running")
    with db() as c:
        if action == "delete":
            c.execute("DELETE FROM vps WHERE name=?", (name,))
        elif action == "resetpass":
            c.execute("UPDATE vps SET password=? WHERE name=?", (new_password, name))
        else:
            c.execute("UPDATE vps SET status=? WHERE name=?", (status, name))


def owner_ids(username):
    """Panel username + linked (verified) Discord ID."""
    ids = [username]
    with db() as c:
        r = c.execute("SELECT discord_id FROM users WHERE username=?", (username,)).fetchone()
    if r and r["discord_id"]:
        ids.append(r["discord_id"])
    return ids


def vps_for(ids):
    q = ",".join("?" * len(ids))
    with db() as c:
        return c.execute(f"SELECT * FROM vps WHERE owner IN ({q}) ORDER BY id DESC", ids).fetchall()


def row_dict(r):
    return {"name": r["name"], "kind": r["kind"], "status": r["status"], "node": r["node"],
            "os": r["os_image"], "username": r["guest_username"], "password": r["password"],
            "ram": r["ram"], "cpu": r["cpu"], "disk": r["disk"], "ssh": ssh_cmd(r),
            "ssh_ts": ssh_ts_cmd(r), "kind_label": KIND_LABEL.get(r["kind"], r["kind"])}


# ───────────────────────── security ─────────────────────────
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(24)
    return session["_csrf"]


app.jinja_env.globals.update(csrf_token=csrf_token, ssh_cmd=ssh_cmd, ssh_ts_cmd=ssh_ts_cmd, KIND_LABEL=KIND_LABEL, OS_OPTIONS=OS_OPTIONS,
                             MAX_VPS_PER_USER=MAX_VPS_PER_USER)


def safe_eq(a, b):
    return hmac.compare_digest(str(a).encode(), str(b).encode())


@app.before_request
def csrf_protect():
    if request.method == "POST" and not request.path.startswith("/api/bot/"):
        if not safe_eq(request.form.get("_csrf", ""), session.get("_csrf", "-")):
            abort(400, "CSRF check failed. Reload the page and try again.")


_attempts = defaultdict(deque)


def too_many_logins():
    now, q = time.time(), _attempts[request.remote_addr]
    while q and now - q[0] > 300:
        q.popleft()
    return len(q) >= 8


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if "username" not in session:
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if session.get("role") != "admin":
            abort(403)
        return fn(*a, **kw)
    return wrapper


def api_auth():
    return safe_eq(request.headers.get("X-Zetta-Secret", ""), API_SECRET) and bool(API_SECRET)


# ───────────────────────── web routes ─────────────────────────
@app.route("/")
@login_required
def index():
    rows = vps_for(owner_ids(session["username"]))
    stats = {"total": len(rows), "running": sum(r["status"] == "running" for r in rows),
             "ram": sum(r["ram"] for r in rows), "cpu": sum(r["cpu"] for r in rows),
             "disk": sum(r["disk"] for r in rows)}
    return render_template("index.html", rows=rows, stats=stats, username=session["username"])


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if too_many_logins():
            flash("Too many attempts. Try again in a few minutes.")
            return render_template("login.html", mode="Login"), 429
        with db() as c:
            u = c.execute("SELECT * FROM users WHERE username=?",
                          (request.form.get("username", "").strip(),)).fetchone()
        if u and check_password_hash(u["password"], request.form.get("password", "")):
            session.clear()
            session["username"], session["role"] = u["username"], u["role"]
            return redirect("/")
        _attempts[request.remote_addr].append(time.time())
        flash("Invalid username or password")
    return render_template("login.html", mode="Login")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{2,23}", username) or len(password) < 8:
            flash("Username: 3-24 chars, must start with a letter (letters/numbers/underscore). Password: 8+ characters.")
        else:
            try:
                with db() as c:
                    c.execute("INSERT INTO users(username,password) VALUES(?,?)",
                              (username, generate_password_hash(password)))
                flash("Account created. Please log in.")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username already exists.")
    return render_template("login.html", mode="Register")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/create", methods=["POST"])
@login_required
def create():
    try:
        f = request.form
        info = create_vps(session["username"], f.get("kind", "docker"), f.get("ram"), f.get("cpu"), f.get("disk"),
                          f.get("node"), f.get("guest_username"), f.get("os_image"),
                          unlimited=session.get("role") == "admin")
        flash(f"Created {info['hostname']} | user: {info['username']} | password: {info['password']} | {info['ssh']}")
        if info.get("ssh_ts"):
            flash("Tailscale: " + info["ssh_ts"])
        for n in info.get("notes", []):
            flash("⚠ " + n)
    except Exception as e:
        flash(f"Create failed: {e}")
    return redirect("/")


@app.route("/action/<int:vps_id>/<action>", methods=["POST"])
@login_required
def action(vps_id, action):
    if action not in ACTIONS:
        flash("Invalid action.")
        return redirect(request.referrer or "/")
    with db() as c:
        row = c.execute("SELECT * FROM vps WHERE id=?", (vps_id,)).fetchone()
    if not row or (session.get("role") != "admin" and row["owner"] not in owner_ids(session["username"])):
        flash("VPS not found.")
        return redirect("/")
    try:
        newpass = secrets.token_urlsafe(12) if action == "resetpass" else None
        control(row, action, newpass)
        flash(f"New password for {row['name']}: {newpass}" if newpass
              else f"{action.title()} completed for {row['name']}.")
    except Exception as e:
        flash(f"Action failed: {e}")
    return redirect(request.referrer or "/")


@app.route("/sshx/<int:vps_id>", methods=["POST"])
@login_required
def sshx(vps_id):
    with db() as c:
        row = c.execute("SELECT * FROM vps WHERE id=?", (vps_id,)).fetchone()
    if not row or (session.get("role") != "admin" and row["owner"] not in owner_ids(session["username"])):
        flash("VPS not found.")
        return redirect("/")
    try:
        flash("SSHX: " + start_sshx(row))
    except Exception as e:
        flash(f"SSHX failed: {e}")
    return redirect(request.referrer or "/")


@app.route("/sync", methods=["POST"])
@login_required
def sync():
    rows = vps_for(owner_ids(session["username"]))
    if session.get("role") == "admin" and request.form.get("all"):
        with db() as c:
            rows = c.execute("SELECT * FROM vps").fetchall()
    sync_rows(rows)
    flash("Status synced.")
    return redirect(request.referrer or "/")


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    me = session["username"]
    if request.method == "POST":
        what = request.form.get("what")
        with db() as c:
            if what == "linkcode":
                code = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
                c.execute("UPDATE users SET link_code=?, link_expires=? WHERE username=?",
                          (code, int(time.time()) + 600, me))
                flash("Link code generated. In Discord run /link and paste it within 10 minutes.")
            elif what == "unlink":
                c.execute("UPDATE users SET discord_id=NULL WHERE username=?", (me,))
                flash("Discord account unlinked.")
            elif what == "password":
                u = c.execute("SELECT * FROM users WHERE username=?", (me,)).fetchone()
                new = request.form.get("new_password", "")
                if not check_password_hash(u["password"], request.form.get("old_password", "")):
                    flash("Current password is wrong.")
                elif len(new) < 8:
                    flash("New password must be at least 8 characters.")
                else:
                    c.execute("UPDATE users SET password=? WHERE username=?", (generate_password_hash(new), me))
                    flash("Password changed.")
        return redirect(url_for("profile"))
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE username=?", (me,)).fetchone()
    code = u["link_code"] if u["link_code"] and (u["link_expires"] or 0) > time.time() else None
    return render_template("profile.html", u=u, code=code, username=me)


@app.route("/admin")
@admin_required
def admin():
    with db() as c:
        rows = c.execute("SELECT * FROM vps ORDER BY id DESC").fetchall()
        users = c.execute("SELECT id,username,role,discord_id FROM users ORDER BY id").fetchall()
    return render_template("admin.html", rows=rows, users=users, username=session["username"])


# ───────────────────────── bot API ─────────────────────────
def _bot_json():
    if not api_auth():
        abort(401)
    return request.get_json(force=True, silent=True) or {}


@app.errorhandler(401)
def _e401(e):
    return ({"error": "Unauthorized"}, 401) if request.path.startswith("/api/") else ("Unauthorized", 401)


@app.post("/api/bot/create")
def bot_create():
    d = _bot_json()
    owner = str(d.get("owner", "")).strip()
    if not owner:
        return {"error": "Missing owner"}, 400
    try:
        return create_vps(owner, d.get("kind", "docker"), d.get("ram", 1), d.get("cpu", 1), d.get("disk", 10),
                          d.get("node", "free"), d.get("username", "ubuntu"), d.get("os", "ubuntu-24.04"))
    except ValueError as e:
        return {"error": str(e)}, 400
    except Exception as e:
        return {"error": str(e)}, 500


def _bot_owner_ids(owner):
    ids = [owner]
    with db() as c:
        r = c.execute("SELECT username FROM users WHERE discord_id=?", (owner,)).fetchone()
    if r:
        ids.append(r["username"])
    return ids


def _bot_row(d):
    ids = _bot_owner_ids(str(d.get("owner", "")))
    q = ",".join("?" * len(ids))
    with db() as c:
        return c.execute(f"SELECT * FROM vps WHERE name=? AND owner IN ({q})",
                         [d.get("hostname"), *ids]).fetchone()


@app.post("/api/bot/list")
def bot_list():
    d = _bot_json()
    rows = vps_for(_bot_owner_ids(str(d.get("owner", ""))))
    if d.get("sync"):
        sync_rows(rows)
        rows = vps_for(_bot_owner_ids(str(d.get("owner", ""))))
    return {"vps": [row_dict(r) for r in rows]}


@app.post("/api/bot/info")
def bot_info():
    d = _bot_json()
    row = _bot_row(d)
    if not row:
        return {"error": "VPS not found for this owner"}, 404
    sync_rows([row])
    return row_dict(_bot_row(d))


@app.post("/api/bot/action")
def bot_action():
    d = _bot_json()
    row = _bot_row(d)
    if not row:
        return {"error": "VPS not found for this owner"}, 404
    action = d.get("action")
    if action not in ACTIONS:
        return {"error": "Invalid action"}, 400
    try:
        newpass = secrets.token_urlsafe(12) if action == "resetpass" else None
        control(row, action, newpass)
        return {"ok": True, "password": newpass}
    except Exception as e:
        return {"error": str(e)}, 500


@app.post("/api/bot/link")
def bot_link():
    d = _bot_json()
    owner, code = str(d.get("owner", "")).strip(), str(d.get("code", "")).strip().upper()
    if not owner or not code:
        return {"error": "Missing owner or code"}, 400
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE link_code=? AND link_expires>?", (code, int(time.time()))).fetchone()
        if not u:
            return {"error": "Invalid or expired code. Generate a new one in the panel (Profile page)."}, 400
        if c.execute("SELECT 1 FROM users WHERE discord_id=? AND id!=?", (owner, u["id"])).fetchone():
            return {"error": "This Discord account is already linked to another panel user."}, 400
        c.execute("UPDATE users SET discord_id=?, link_code=NULL, link_expires=NULL WHERE id=?", (owner, u["id"]))
    return {"ok": True, "username": u["username"]}


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8888")))
