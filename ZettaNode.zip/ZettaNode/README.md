# ZettaNode Custom VPS Control
Credit: made by tyrkrox_tech

## Architecture
- `panel/`: FastAPI web panel; deploy this on Railway.
- `node/`: authenticated Incus API agent; install on a separate real Ubuntu 22.04/24.04 VM.
- `bot/`: optional Discord slash-command bot.

**Important:** Do not run Incus VPS workloads inside Railway. Your screenshots show Railway starts the Incus daemon but denies nested shared-mount setup when starting instances. A separate VM with host-level Incus permissions is required. This project does not bypass host restrictions.

## Install the Incus node
On a real Ubuntu VM, copy `node/` and run:
```bash
cd node && sudo bash install.sh
```
The installer generates `/opt/zettanode-node/.env`. Copy its `NODE_API_TOKEN` securely.
The agent binds to `127.0.0.1:8787` by default. Put it behind HTTPS or a private VPN before connecting from Railway. Never expose the raw agent over public HTTP.

Configure Incus on that VM (`sudo incus admin init`). Ensure its default profile has a root disk and a usable network.

## Deploy panel on Railway
Set Railway root directory to `panel/`, then set:
- `APP_SECRET`: long random secret (32+ characters)
- `ADMIN_EMAIL`: admin email
- `ADMIN_PASSWORD`: strong admin password
- `NODE_API_URL`: HTTPS URL of your protected node agent
- `NODE_API_TOKEN`: same token as node agent
Railway supplies `PORT`. Locally it defaults to 8888.

## Run locally
```bash
cd panel
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8888
```

## Optional Discord bot
```bash
cd bot
pip install -r requirements.txt
export DISCORD_TOKEN='...'
export MAIN_ADMIN_ID='your-discord-user-id'
python bot.py
```
Commands: `/health`, admin-only `/announcement`.

## Included
Login/register, user/admin roles, VPS create/list, start/stop/restart/reinstall/delete, admin role management, CPU/RAM/disk limits, token-authenticated node API, audit events.

## Not included yet
KVM VMs, public IPv4/NAT allocation, billing, password reset/email verification, interactive web terminal, multi-node scheduler, automated backups, rate limiting and full CSRF protection. The current node provisions Incus containers only. Secure and test on a non-production node before inviting users.
