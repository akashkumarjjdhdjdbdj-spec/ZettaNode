import os,re,subprocess,json
from typing import Literal
from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel,Field
TOKEN=os.getenv("NODE_API_TOKEN","")
if len(TOKEN)<32: raise RuntimeError("NODE_API_TOKEN must be 32+ chars")
app=FastAPI(title="ZettaNode Incus Agent")
def auth(h):
    if h!=f"Bearer {TOKEN}":raise HTTPException(401,"Invalid node token")
def valid(n):
    if not re.fullmatch(r"[a-z][a-z0-9-]{2,23}",n):raise HTTPException(400,"Invalid instance name")
def run(args,timeout=240):
    p=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
    if p.returncode:raise HTTPException(400,(p.stderr or p.stdout or "Incus error")[-1000:])
    return p.stdout.strip()
class Create(BaseModel):
    name:str
    image:Literal["images:ubuntu/22.04","images:ubuntu/24.04","images:debian/12"]
    cpu:int=Field(ge=1,le=8)
    memory_mb:int=Field(ge=1024,le=16384)
    disk_gb:int=Field(ge=5,le=100)
@app.get("/health")
def health():return {"ok":True,"service":"zettanode-node"}
@app.post("/instances")
def create(b:Create,authorization:str|None=Header(default=None)):
    auth(authorization);valid(b.name)
    run(["incus","launch",b.image,b.name,"-c",f"limits.cpu={b.cpu}","-c",f"limits.memory={b.memory_mb}MB"],300)
    run(["incus","config","device","override",b.name,"root",f"size={b.disk_gb}GB"])
    return {"ok":True,"name":b.name}
@app.post("/instances/{name}/{action}")
def act(name:str,action:Literal["start","stop","restart"],authorization:str|None=Header(default=None)):
    auth(authorization);valid(name);run(["incus",action,name]);return {"ok":True,"name":name,"action":action}
@app.post("/instances/{name}/reinstall")
def reinstall(name:str,b:Create,authorization:str|None=Header(default=None)):
    auth(authorization);valid(name)
    if name!=b.name:raise HTTPException(400,"Name mismatch")
    run(["incus","delete",name,"--force"])
    run(["incus","launch",b.image,name,"-c",f"limits.cpu={b.cpu}","-c",f"limits.memory={b.memory_mb}MB"],300)
    run(["incus","config","device","override",name,"root",f"size={b.disk_gb}GB"])
    return {"ok":True,"reinstalled":name}
@app.delete("/instances/{name}")
def delete(name:str,authorization:str|None=Header(default=None)):
    auth(authorization);valid(name);run(["incus","delete",name,"--force"]);return {"ok":True}
@app.get("/instances")
def listing(authorization:str|None=Header(default=None)):
    auth(authorization);return {"instances":json.loads(run(["incus","list","--format","json"]))}
