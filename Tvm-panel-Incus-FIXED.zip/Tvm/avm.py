"""Compatibility shim for legacy `import avm` references.

The application core lives in Tvm.py. Importing this module exposes that same
module object so API routes and legacy extensions share the same Flask app,
database helpers, Incus functions, and configuration.
"""
import sys
import Tvm as _panel_core
sys.modules[__name__] = _panel_core
