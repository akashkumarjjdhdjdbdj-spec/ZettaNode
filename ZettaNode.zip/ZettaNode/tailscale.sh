#!/usr/bin/env bash
# ZettaNode — Tailscale setup. Lets you reach the panel and every VPS over a private Tailscale network.
set -Eeuo pipefail
trap 'echo; echo "TAILSCALE SETUP FAILED at line $LINENO. Read the error above."; exit 1' ERR
[[ $EUID -eq 0 ]] || { echo "Run: sudo bash tailscale.sh"; exit 1; }
export DEBIAN_FRONTEND=noninteractive
say() { echo -e "\n\033[1;36m==> $*\033[0m"; }

HAS_SYSTEMD=0; [[ -d /run/systemd/system ]] && HAS_SYSTEMD=1
HAS_TUN=0; [[ -e /dev/net/tun ]] && HAS_TUN=1

if ! command -v tailscale >/dev/null 2>&1; then
  say "Installing Tailscale"
  command -v curl >/dev/null 2>&1 || { apt-get update; apt-get install -y curl ca-certificates; }
  curl -fsSL https://tailscale.com/install.sh | sh
fi

# Kernel mode (real server) = full access to the panel AND all VPS SSH ports.
# Userspace mode (containers like Railway: no systemd / no /dev/net/tun) = works, but only forwards ports we publish with `tailscale serve`.
MODE=kernel
if (( ! HAS_SYSTEMD )) || (( ! HAS_TUN )); then MODE=userspace; fi
say "Mode: $MODE"

if [[ "$MODE" == "kernel" ]]; then
  systemctl enable --now tailscaled
else
  mkdir -p /var/lib/tailscale /var/run/tailscale
  if ! pgrep -x tailscaled >/dev/null 2>&1; then
    nohup tailscaled --tun=userspace-networking --state=/var/lib/tailscale/tailscaled.state \
      --socket=/var/run/tailscale/tailscaled.sock > /var/log/tailscaled.log 2>&1 &
    sleep 4
  fi
fi

read -rp "Device name on your tailnet [zettanode]: " TS_NAME; TS_NAME="${TS_NAME:-zettanode}"
read -rsp "Auth key (tskey-auth-..., from login.tailscale.com/admin/settings/keys) — Enter to log in with a link instead: " TS_KEY; echo
read -rp "Also enable Tailscale SSH for this server? [y/N]: " TS_SSH
ARGS=(--hostname "$TS_NAME" --accept-dns=false)
[[ "$TS_SSH" =~ ^[Yy]$ ]] && ARGS+=(--ssh)
if [[ -n "$TS_KEY" ]]; then
  tailscale up --authkey "$TS_KEY" "${ARGS[@]}"
else
  echo "Open the login link that appears below in your browser…"
  tailscale up "${ARGS[@]}"
fi

TS_IP="$(tailscale ip -4 | head -1)"
[[ -n "$TS_IP" ]] || { echo "No Tailscale IP yet. Check: tailscale status"; exit 1; }

if [[ "$MODE" == "userspace" ]]; then
  say "Publishing the panel (port 8888) on your tailnet"
  tailscale serve --bg --tcp 8888 tcp://127.0.0.1:8888 \
    || echo "Could not run 'tailscale serve' automatically (CLI version differs). Run: tailscale serve --help"
fi

if (( HAS_SYSTEMD )) && systemctl list-unit-files 2>/dev/null | grep -q '^zettanode-panel'; then
  systemctl restart zettanode-panel || true
fi

echo
say "Tailscale is up"
echo "  Tailscale IP : $TS_IP"
echo "  Panel (tailnet): http://$TS_IP:8888"
if [[ "$MODE" == "kernel" ]]; then
  echo "  VPS SSH        : ssh USER@$TS_IP -p <port>   (the panel/bot now show this 'Tailscale' command for every VPS)"
  echo "  Tip: to make the panel/VPS reachable ONLY over Tailscale, block 8888 and 20000-29999 on the public interface, e.g."
  echo "       ufw allow in on tailscale0 && ufw deny 8888 && ufw deny 20000:29999/tcp"
else
  echo "  Userspace mode only publishes the panel. For VPS SSH ports you need a real server (systemd + /dev/net/tun)."
fi
echo "  Other devices must be on the same tailnet (install Tailscale there and log in to the same account)."
