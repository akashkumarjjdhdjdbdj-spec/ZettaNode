#!/usr/bin/env bash
# ZettaNode — Pterodactyl Panel + Wings (node) installer.
# Installs on the HOST server (not inside a ZettaNode VPS). Ubuntu 22.04 / 24.04 or Debian 11 / 12 with systemd.
set -Eeuo pipefail
trap 'echo; echo "PTERODACTYL INSTALL FAILED at line $LINENO. Read the error above."; exit 1' ERR

PANEL_DIR=/var/www/pterodactyl
CRED=/root/pterodactyl-credentials.txt
export DEBIAN_FRONTEND=noninteractive COMPOSER_ALLOW_SUPERUSER=1

[[ $EUID -eq 0 ]] || { echo "Run: sudo bash pterodactyl.sh"; exit 1; }
[[ -d /run/systemd/system ]] || { echo "systemd not found. Pterodactyl needs a real server (VPS/dedicated) — it cannot run in Railway/Docker containers."; exit 1; }
. /etc/os-release
case "${ID}" in ubuntu|debian) ;; *) echo "Unsupported OS: ${ID}. Use Ubuntu 22.04/24.04 or Debian 11/12."; exit 1;; esac
[[ "$(uname -m)" == "x86_64" || "$(uname -m)" == "aarch64" ]] || { echo "Unsupported CPU architecture."; exit 1; }

say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
rand() { python3 - <<'PY'
import secrets, string
print(''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(24)))
PY
}
port_busy() { ss -ltn "( sport = :$1 )" 2>/dev/null | grep -q LISTEN; }
art() { (cd "$PANEL_DIR" && php artisan "$@"); }

install_docker_if_needed() {
  if ! command -v docker >/dev/null 2>&1; then
    say "Installing Docker"
    curl -fsSL https://get.docker.com | CHANNEL=stable bash
  fi
  systemctl enable --now docker
}

# ───────────────────────── PANEL ─────────────────────────
install_panel() {
  if [[ -f "$PANEL_DIR/.env" ]]; then echo "Panel already installed in $PANEL_DIR — refusing to overwrite."; exit 1; fi
  if port_busy 80; then echo "Port 80 is already in use. Stop that service first (apache/nginx?)."; exit 1; fi

  read -rp "Panel domain or server IP (e.g. panel.example.com or 1.2.3.4): " FQDN
  [[ -n "$FQDN" ]] || { echo "Domain/IP is required."; exit 1; }
  read -rp "Admin email: " ADMIN_EMAIL
  [[ "$ADMIN_EMAIL" == *@*.* ]] || { echo "Enter a valid email."; exit 1; }
  read -rp "Admin username [admin]: " ADMIN_USER; ADMIN_USER="${ADMIN_USER:-admin}"
  while true; do
    read -rsp "Admin password (8+ chars, upper + lower + number): " ADMIN_PASS; echo
    if [[ ${#ADMIN_PASS} -ge 8 && "$ADMIN_PASS" =~ [A-Z] && "$ADMIN_PASS" =~ [a-z] && "$ADMIN_PASS" =~ [0-9] ]]; then break; fi
    echo "Too weak. Try again."
  done
  USE_SSL=n
  if [[ ! "$FQDN" =~ ^[0-9.]+$ ]]; then read -rp "Get a free HTTPS certificate (Let's Encrypt) now? DNS must already point here [y/N]: " USE_SSL; fi

  say "Installing packages"
  apt-get update
  apt-get install -y software-properties-common curl ca-certificates gnupg2 lsb-release tar unzip git cron nginx mariadb-server redis-server python3
  if [[ "$ID" == "ubuntu" ]]; then
    LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php || true
  else
    curl -fsSL https://packages.sury.org/php/apt.gpg -o /etc/apt/trusted.gpg.d/sury-php.gpg
    echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/sury-php.list
  fi
  apt-get update
  PHPV=""
  for v in 8.3 8.2; do
    if apt-cache madison "php${v}-fpm" 2>/dev/null | grep -q .; then PHPV=$v; break; fi
  done
  [[ -n "$PHPV" ]] || { echo "PHP 8.2/8.3 is not available for ${PRETTY_NAME}. Use Ubuntu 22.04/24.04 or Debian 12 for the panel."; exit 1; }
  say "Using PHP $PHPV"
  apt-get install -y "php${PHPV}"-{cli,gd,mysql,mbstring,bcmath,xml,fpm,curl,zip}
  systemctl enable --now "php${PHPV}-fpm" mariadb redis-server nginx cron

  say "Installing Composer"
  curl -fsSL https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer

  say "Downloading Pterodactyl Panel"
  mkdir -p "$PANEL_DIR"
  curl -fL -o /tmp/panel.tar.gz https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz
  tar -xzf /tmp/panel.tar.gz -C "$PANEL_DIR"
  rm -f /tmp/panel.tar.gz
  chmod -R 755 "$PANEL_DIR"/storage/* "$PANEL_DIR"/bootstrap/cache/

  say "Creating database"
  DBCLI="$(command -v mariadb || command -v mysql)"
  DB_PASS="$(rand)"
  "$DBCLI" -u root <<SQL
CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
ALTER USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
CREATE DATABASE IF NOT EXISTS panel;
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL

  say "Configuring panel"
  cd "$PANEL_DIR"
  cp .env.example .env
  composer install --no-dev --optimize-autoloader --no-interaction
  art key:generate --force
  SCHEME=http
  if [[ "$USE_SSL" =~ ^[Yy]$ ]]; then SCHEME=https; fi
  ENVSET=(p:environment:setup --author="$ADMIN_EMAIL" --url="${SCHEME}://${FQDN}" --timezone=UTC
          --cache=redis --session=redis --queue=redis --redis-host=127.0.0.1 --redis-pass= --redis-port=6379
          --settings-ui=true --no-interaction)
  art "${ENVSET[@]}" --telemetry=false || art "${ENVSET[@]}"
  art p:environment:database --host=127.0.0.1 --port=3306 --database=panel --username=pterodactyl --password="$DB_PASS" --no-interaction
  art migrate --seed --force
  art p:user:make --email="$ADMIN_EMAIL" --username="$ADMIN_USER" --name-first=Admin --name-last=User \
      --password="$ADMIN_PASS" --admin=1 --no-interaction
  chown -R www-data:www-data "$PANEL_DIR"

  say "Cron + queue worker"
  { crontab -l 2>/dev/null || true; } | { grep -v 'pterodactyl/artisan' || true; } > /tmp/cron.new
  echo "* * * * * php $PANEL_DIR/artisan schedule:run >> /dev/null 2>&1" >> /tmp/cron.new
  crontab /tmp/cron.new && rm -f /tmp/cron.new
  cat > /etc/systemd/system/pteroq.service <<'EOF'
[Unit]
Description=Pterodactyl Queue Worker
After=redis-server.service

[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php /var/www/pterodactyl/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now pteroq

  say "Configuring nginx"
  rm -f /etc/nginx/sites-enabled/default
  cat > /etc/nginx/sites-available/pterodactyl.conf <<'EOF'
server {
    listen 80;
    server_name @FQDN@;
    root /var/www/pterodactyl/public;
    index index.html index.htm index.php;
    charset utf-8;

    location / { try_files $uri $uri/ /index.php?$query_string; }
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    access_log off;
    error_log  /var/log/nginx/pterodactyl.app-error.log error;

    client_max_body_size 100m;
    client_body_timeout 120s;
    sendfile off;

    location ~ \.php$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass unix:/run/php/php@PHPV@-fpm.sock;
        fastcgi_index index.php;
        include /etc/nginx/fastcgi_params;
        fastcgi_param PHP_VALUE "upload_max_filesize = 100M \n post_max_size=100M";
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }
    location ~ /\.ht { deny all; }
}
EOF
  sed -i "s/@FQDN@/${FQDN}/; s/@PHPV@/${PHPV}/" /etc/nginx/sites-available/pterodactyl.conf
  ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
  nginx -t
  systemctl restart nginx

  if [[ "$USE_SSL" =~ ^[Yy]$ ]]; then
    say "Requesting HTTPS certificate"
    apt-get install -y certbot python3-certbot-nginx
    certbot --nginx -d "$FQDN" --non-interactive --agree-tos -m "$ADMIN_EMAIL" --redirect \
      || { echo "Certbot failed (DNS not pointing here?). Panel still works on http. APP_URL was set to https — fix with: cd $PANEL_DIR && php artisan p:environment:setup"; }
  fi

  umask 077
  cat > "$CRED" <<EOF
Pterodactyl panel : ${SCHEME}://${FQDN}
Admin username    : ${ADMIN_USER}
Admin email       : ${ADMIN_EMAIL}
Database user     : pterodactyl
Database password : ${DB_PASS}
EOF
  PANEL_URL="${SCHEME}://${FQDN}"
  say "Panel installed: ${PANEL_URL}   (details saved in $CRED)"
}

# ───────────────────────── WINGS (NODE) ─────────────────────────
install_wings_binary() {
  install_docker_if_needed
  say "Installing Wings"
  mkdir -p /etc/pterodactyl /var/lib/pterodactyl
  ARCH=amd64
  if [[ "$(uname -m)" == "aarch64" ]]; then ARCH=arm64; fi
  curl -fL -o /usr/local/bin/wings "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_${ARCH}"
  chmod u+x /usr/local/bin/wings
  cat > /etc/systemd/system/wings.service <<'EOF'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
}

# Wings on the same server as the panel: create location + node from the CLI, then write config.yml
setup_local_node() {
  if [[ ! -f "$PANEL_DIR/.env" ]]; then echo "Panel is not installed on this server."; exit 1; fi
  read -rp "Node public domain/IP (how the browser reaches Wings) [${FQDN:-this server's IP}]: " NODE_FQDN
  NODE_FQDN="${NODE_FQDN:-${FQDN:-}}"
  [[ -n "$NODE_FQDN" ]] || { echo "Node domain/IP is required."; exit 1; }
  NODE_SCHEME=http   # Wings listens on plain http:8080 by default; put it behind HTTPS later if your panel uses HTTPS
  RAM_MB="$(free -m | awk '/^Mem:/{print $2}')"
  DISK_MB="$(df -m --output=avail /var/lib | tail -1 | tr -d ' ')"
  say "Creating location + node in the panel (RAM ${RAM_MB} MB, disk ${DISK_MB} MB)"
  art p:location:make --short=main --long="ZettaNode" --no-interaction
  DBCLI="$(command -v mariadb || command -v mysql)"
  LOC_ID="$("$DBCLI" -u root -N -e 'SELECT id FROM panel.locations ORDER BY id DESC LIMIT 1')"
  NODEARGS=(p:node:make --name="ZettaNode-1" --description="Local Wings node" --locationId="$LOC_ID" --fqdn="$NODE_FQDN"
            --public=1 --scheme="$NODE_SCHEME" --proxy=0 --maintenance=0 --maxMemory="$RAM_MB" --overallocateMemory=0
            --maxDisk="$DISK_MB" --overallocateDisk=0 --daemonListeningPort=8080 --daemonSFTPPort=2022
            --daemonBase=/var/lib/pterodactyl/volumes --no-interaction)
  if ! art "${NODEARGS[@]}" --uploadSize=100; then art "${NODEARGS[@]}"; fi
  NODE_ID="$("$DBCLI" -u root -N -e 'SELECT id FROM panel.nodes ORDER BY id DESC LIMIT 1')"
  art p:node:configuration "$NODE_ID" > /etc/pterodactyl/config.yml
  chmod 600 /etc/pterodactyl/config.yml
  grep -q '^token:' /etc/pterodactyl/config.yml || { echo "config.yml looks wrong (no token). Create the node in the panel and copy its config."; exit 1; }
  systemctl enable --now wings
  sleep 3
  systemctl is-active --quiet wings && say "Wings is running (node #$NODE_ID). It should turn green in Admin → Nodes within ~1 minute." \
    || { echo "Wings did not start. Check: journalctl -u wings -n 50"; exit 1; }
}

# Wings for a panel that lives on ANOTHER server (use the 'configure' command from Admin → Nodes → Configuration)
setup_remote_node() {
  read -rp "Panel URL (e.g. https://panel.example.com): " R_URL
  read -rp "Node ID (number shown in the panel): " R_ID
  read -rsp "Application/Node token (from Admin → Nodes → Configuration → Generate Token): " R_TOKEN; echo
  [[ -n "$R_URL" && "$R_ID" =~ ^[0-9]+$ && -n "$R_TOKEN" ]] || { echo "All three values are required."; exit 1; }
  (cd /etc/pterodactyl && /usr/local/bin/wings configure --panel-url "$R_URL" --token "$R_TOKEN" --node "$R_ID")
  systemctl enable --now wings
  sleep 3
  systemctl is-active --quiet wings && say "Wings is running." || { echo "Wings did not start. Check: journalctl -u wings -n 50"; exit 1; }
}

echo "=== ZettaNode · Pterodactyl installer ==="
echo " 1) Panel only"
echo " 2) Wings (node) only — panel is on another server"
echo " 3) Panel + Wings (node) on this server"
read -rp "Choose [3]: " CHOICE; CHOICE="${CHOICE:-3}"

case "$CHOICE" in
  1) install_panel ;;
  2) install_wings_binary; setup_remote_node ;;
  3) install_panel; install_wings_binary; setup_local_node ;;
  *) echo "Invalid choice."; exit 1 ;;
esac

echo
echo "Open these ports in your firewall: 80 (panel), 443 (if HTTPS), 8080 (Wings), 2022 (Wings SFTP)."
echo "Do NOT use ports 8888 or 20000-29999 for game servers (ZettaNode uses them)."
