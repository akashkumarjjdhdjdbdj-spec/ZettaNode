import os,discord
from discord import app_commands
TOKEN=os.getenv("DISCORD_TOKEN","");ADMIN=int(os.getenv("MAIN_ADMIN_ID","0"))
if not TOKEN:raise RuntimeError("Set DISCORD_TOKEN")
class Client(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default());self.tree=app_commands.CommandTree(self)
    async def setup_hook(self):await self.tree.sync()
bot=Client()
@bot.event
async def on_ready():print(f"ZettaNode online: {bot.user}")
@bot.tree.command(name="health",description="Check ZettaNode bot status")
async def health(i:discord.Interaction):await i.response.send_message("🟢 ZettaNode bot is online.",ephemeral=True)
@bot.tree.command(name="announcement",description="Admin announcement in this channel")
@app_commands.describe(message="Announcement text")
async def announcement(i:discord.Interaction,message:str):
    if i.user.id!=ADMIN:return await i.response.send_message("Not authorized.",ephemeral=True)
    if len(message)>1800:return await i.response.send_message("Message too long (max 1800).",ephemeral=True)
    e=discord.Embed(title="📢 ZettaNode Announcement",description=message,color=0x8B5CF6)
    e.set_footer(text="made by tyrkrox_tech")
    await i.response.send_message(embed=e)
bot.run(TOKEN)
