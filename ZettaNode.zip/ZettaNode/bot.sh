#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "BOT SETUP FAILED at line $LINENO. Check the error above."; exit 1' ERR
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== ZettaNode Custom VPS Control — Discord Bot Setup ==="
command -v python3 >/dev/null || { echo "Install Python 3 first."; exit 1; }
python3 -m venv "$DIR/bot-venv"
"$DIR/bot-venv/bin/pip" install --upgrade pip
"$DIR/bot-venv/bin/pip" install "discord.py>=2.4,<3" "aiohttp>=3.9,<4" "python-dotenv>=1,<2"
if [[ ! -f "$DIR/.env" ]]; then
  read -rsp "Discord bot token: " TOKEN; echo
  read -rp "Discord server ID (0 for global commands): " GUILD
  read -rp "Role ID allowed to create/manage VPS: " ROLE
  read -rp "Panel API URL [http://127.0.0.1:8888]: " API
  API="${API:-http://127.0.0.1:8888}"
  read -rp "Public panel URL shown in /help (optional): " PURL
  if [[ -z "${ZETTA_API_SECRET:-}" && -f "$DIR/panel/.env" ]]; then
    ZETTA_API_SECRET="$(grep -E '^ZETTA_API_SECRET=' "$DIR/panel/.env" | cut -d= -f2-)"
    echo "API secret read automatically from panel/.env"
  fi
  if [[ -z "${ZETTA_API_SECRET:-}" ]]; then read -rsp "ZETTA_API_SECRET (shown by install.sh): " ZETTA_API_SECRET; echo; fi
  umask 077
  cat > "$DIR/.env" <<ENVEOF
DISCORD_TOKEN=$TOKEN
GUILD_ID=$GUILD
CREATE_ROLE_ID=$ROLE
PANEL_API=$API
PANEL_URL=$PURL
ZETTA_API_SECRET=$ZETTA_API_SECRET
ENVEOF
fi
chmod 600 "$DIR/.env"

if [[ $EUID -eq 0 ]] && command -v systemctl >/dev/null && [[ ! -f /etc/systemd/system/zettanode-bot.service ]]; then
  read -rp "Install as a systemd service (auto-start, auto-restart)? [Y/n]: " SVC
  if [[ "${SVC:-Y}" =~ ^[Yy]$ ]]; then
    cat > /etc/systemd/system/zettanode-bot.service <<SVCEOF
[Unit]
Description=ZettaNode Discord Bot
After=network-online.target zettanode-panel.service
Wants=network-online.target
[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/bot-venv/bin/python $DIR/bot.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVCEOF
    systemctl daemon-reload
    systemctl enable --now zettanode-bot
    echo "Bot service started. Logs: journalctl -u zettanode-bot -f"
    exit 0
  fi
fi
echo "Starting ZettaNode Discord bot..."
exec "$DIR/bot-venv/bin/python" "$DIR/bot.py"
