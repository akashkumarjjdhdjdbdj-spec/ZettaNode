# ZettaNode Custom VPS Control
**Credit:** made by tyrkrox_tech

## Included
- `install.sh` — installs the web panel (systemd service), Docker and lxcfs.
- `bot.sh` — installs the Discord bot, asks for token/role/API details, optionally installs it as a systemd service.
- `panel/` — Flask panel (Nebula Glass theme: Nebula / Aurora / Light).
- `bot.py` — role-gated Discord bot.

## Deploy
Use a dedicated Ubuntu server where the Docker daemon can run.
```bash
cd ZettaNode
sudo bash install.sh     # panel on http://SERVER_IP:8888
sudo bash bot.sh         # discord bot (reads the API secret from panel/.env automatically)
```
Bot invite scopes: `bot` + `applications.commands`.
Open firewall ports: **8888** (panel) and **20000-29999** (VPS SSH).

## Panel features
- Themes: Nebula, Aurora, Light (saved in your browser)
- Dashboard stats, search, live status **Sync**, show/copy password, copy SSH command
- Start / Stop / Restart / Suspend / Unsuspend / Reinstall / Delete / **New password**
- Per-user VPS limit (`MAX_VPS_PER_USER` in `panel/.env`, default 3; admin unlimited)
- Profile page: change password, **link Discord**
- Admin page: all users and all VPS
- Security: CSRF protection, login rate-limit, secure session cookies, API secret compared in constant time

## Bot commands
| Command | What it does |
|---|---|
| `/create` | Create a Docker VPS (node, OS, username, RAM, CPU, disk) |
| `/list` | Your VPS with live status |
| `/info` | Login details (password is a spoiler) |
| `/manage` | start / stop / restart / suspend / unsuspend / reinstall / delete (confirm button for destructive ones) |
| `/resetpass` | New password |
| `/link` | Link Discord to your panel account (code from panel → Profile) |
| `/help` | Command list |

VPS created in Discord belong to the Discord ID. After `/link`, they also appear in the linked panel account.

## Supported OS (17, all Docker)
Ubuntu 24.04 / 22.04 / 20.04 · Debian 13 / 12 / 11 · AlmaLinux 9 / 8 · Rocky Linux 9 / 8 · CentOS Stream 9 · Fedora 42 · Arch Linux ·
Alpine · openSUSE Leap 15.6 · openSUSE Tumbleweed · Kali. (Windows/macOS are not possible with Docker.)

## Real RAM / cores / disk inside the VPS
`free -h`, `nproc` and `df -h /` show what you selected: `lxcfs` (installed by install.sh) shows the container limits, RAM is hard-limited (swap off) and CPU is pinned to N cores.
Disk size is only enforced/shown when Docker runs on XFS with quota; `install.sh` offers to create that (answer the disk-quota question with a size in GB, e.g. 100).
If the host cannot do something, the panel/bot show a ⚠ warning when the VPS is created. After `lxcfs` is restarted, restart the Docker VPS.

## Pterodactyl Panel + Node (Wings)
`pterodactyl.sh` installs Pterodactyl on the **host** (it cannot run inside a ZettaNode Docker VPS).
```bash
sudo bash pterodactyl.sh
```
1. Panel only · 2. Wings (node) only for a panel on another server · 3. **Panel + Wings on this server** (creates the location and node automatically and starts Wings).
- Needs a real server with systemd, Ubuntu 22.04/24.04 or Debian 11/12 (PHP 8.2/8.3), port 80 free.
- Runs next to ZettaNode: panel on port 80, Wings on 8080 + SFTP 2022. Open them in your firewall.
- Do not use ports 8888 or 20000-29999 for game servers (ZettaNode uses them).
- Logins are saved in `/root/pterodactyl-credentials.txt`. Optional free HTTPS (Let's Encrypt) if you enter a domain.
- Troubleshooting: `journalctl -u wings -n 50`, `journalctl -u pteroq -n 50`, `tail /var/www/pterodactyl/storage/logs/*.log`.

## SSHX (browser terminal)
Every VPS card has a **🖥 SSHX** button (VPS must be running). It starts `sshx` inside the VPS as the VPS user and shows a link `https://sshx.io/s/...` that opens a shared terminal in the browser. Clicking again reuses the running session. The VPS needs internet access; anyone with the link gets that terminal, so share it carefully. Stop it by restarting the VPS.

## pterodactyl.sh inside every VPS
Every new VPS (Free and Paid, panel or Discord `/create`, also after Reinstall) gets `pterodactyl.sh` in the login user's home folder. After SSH login:
```bash
ls                      # shows pterodactyl.sh
sudo bash pterodactyl.sh
```
Note: inside a Docker VPS there is no systemd/Docker daemon, so the installer will stop with a message; the real install works on the host server.

## KVM-style VPS (not real KVM)
Choosing **KVM-style** (panel "Type" or `/create kind`) still creates a Docker container, but inside it `systemd-detect-virt` / `virt-what` print `kvm`, `systemd-detect-virt --container` says `none`, and `lscpu` shows `Hypervisor vendor: KVM`. It does **not** give a real VM: shared host kernel, no own kernel/Docker-in-VM/nested virtualisation, and tools that read the hardware directly (dmidecode, `/sys/class/dmi`) still show the host. The panel and bot label it honestly as "KVM-style VPS (Docker container)" — do not sell it as real KVM.

## Tailscale
```bash
sudo bash tailscale.sh
```
Installs Tailscale, joins your tailnet (auth key or login link) and prints the Tailscale IP. After that the panel and the bot show an extra **Tailscale** SSH command for every VPS (`ssh user@100.x.y.z -p PORT`) and the panel is reachable at `http://100.x.y.z:8888`.
- Real server (systemd + /dev/net/tun): full access to the panel and all VPS SSH ports. Tip: block 8888 and 20000-29999 on the public interface to make everything Tailscale-only.
- Container hosts (e.g. Railway): userspace mode is used automatically; only the panel (8888) is published over the tailnet.
- Set `TAILSCALE_HOST=100.x.y.z` in `panel/.env` to override auto-detection.

## Themes
Pick from the 🎨 selector (top right): Nebula (default), Aurora, Ocean, Sunset, Cyber, Light, Rose. Saved per browser. Colors live in `panel/static/style.css` (`[data-theme=...]` blocks) — copy one block to make your own.

## Notes
- Hostname is always `ZettaNode-freevps-` + 7 random characters.
- SSH on a fixed host port (20000-29999). First boot installs OpenSSH, so wait ~1 minute.
- Free/Paid are labels on this single host (no remote node agents yet).
- Railway containers normally cannot run a Docker daemon: use a real Ubuntu VPS/dedicated server for provisioning.
- Starter project: add HTTPS (reverse proxy, then set `COOKIE_SECURE=1` in panel/.env), backups, quotas and abuse controls before public use. Never expose the Docker socket.
