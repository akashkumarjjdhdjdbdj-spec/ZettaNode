import os, re, sqlite3, secrets, hashlib, hmac
from datetime import datetime, timezone
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
import httpx

SECRET=os.getenv("APP_SECRET","")
if len(SECRET)<32: SECRET=secrets.token_urlsafe(48)
DB=os.getenv("DATABASE_PATH","zettanode.db")
NODE=os.getenv("NODE_API_URL","").rstrip("/")
TOKEN=os.getenv("NODE_API_TOKEN","")
ADMIN_EMAIL=os.getenv("ADMIN_EMAIL","admin@example.com").lower().strip()
ADMIN_PASSWORD=os.getenv("ADMIN_PASSWORD","")
app=FastAPI(title="ZettaNode Custom VPS Control")
app.add_middleware(SessionMiddleware,secret_key=SECRET,same_site="lax",https_only=os.getenv("COOKIE_HTTPS_ONLY","false").lower()=="true")
templates=Jinja2Templates(directory="templates")

def connect():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def now(): return datetime.now(timezone.utc).isoformat()
def pw_hash(pw,salt=None):
    salt=salt or secrets.token_bytes(16)
    return salt.hex()+"$"+hashlib.scrypt(pw.encode(),salt=salt,n=16384,r=8,p=1).hex()
def pw_ok(pw,stored):
    try:
        s,d=stored.split("$",1)
        return hmac.compare_digest(pw_hash(pw,bytes.fromhex(s)).split("$",1)[1],d)
    except Exception: return False
def init():
    with connect() as c:
        c.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,role TEXT,created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY,owner INTEGER,name TEXT UNIQUE,image TEXT,cpu INTEGER,ram INTEGER,disk INTEGER,status TEXT,created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor INTEGER,action TEXT,detail TEXT,created TEXT)")
        if ADMIN_PASSWORD and not c.execute("SELECT id FROM users WHERE email=?",(ADMIN_EMAIL,)).fetchone():
            c.execute("INSERT INTO users(email,password,role,created) VALUES(?,?,?,?)",(ADMIN_EMAIL,pw_hash(ADMIN_PASSWORD),"admin",now()))
        c.commit()
@app.on_event("startup")
def startup(): init()
def user_for(req):
    uid=req.session.get("uid")
    if not uid:return None
    with connect() as c:
        r=c.execute("SELECT id,email,role FROM users WHERE id=?",(uid,)).fetchone()
        return dict(r) if r else None
def need_user(req):
    u=user_for(req)
    if not u: raise HTTPException(401,"Login required")
    return u
def render(req,t,**kw): return templates.TemplateResponse(t,{"request":req,"user":user_for(req),**kw})
def log(actor,action,detail):
    with connect() as c: c.execute("INSERT INTO audit(actor,action,detail,created) VALUES(?,?,?,?)",(actor,action,detail[:400],now())); c.commit()
async def node(method,path,data=None):
    if not NODE or not TOKEN: raise RuntimeError("Node is not configured in panel environment.")
    async with httpx.AsyncClient(timeout=180,verify=True) as x:
        r=await x.request(method,NODE+path,json=data,headers={"Authorization":"Bearer "+TOKEN})
        if r.is_error:
            try: msg=r.json().get("detail",r.text)
            except Exception: msg=r.text
            raise RuntimeError(str(msg))
        return r.json() if r.content else {}

@app.get("/")
async def dashboard(req:Request):
    u=user_for(req)
    if not u:return RedirectResponse("/login",303)
    with connect() as c:
        if u["role"]=="admin":
            rows=c.execute("SELECT v.*,u.email owner_email FROM vps v JOIN users u ON u.id=v.owner ORDER BY v.id DESC").fetchall()
            n=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        else:
            rows=c.execute("SELECT * FROM vps WHERE owner=? ORDER BY id DESC",(u["id"],)).fetchall(); n=0
    return render(req,"dashboard.html",vps=[dict(x) for x in rows],users_count=n,node_status="Connected config" if NODE and TOKEN else "Not configured",error=req.query_params.get("error"))
@app.get("/login")
async def login_page(req:Request): return render(req,"auth.html",mode="login",error=req.query_params.get("error"))
@app.get("/register")
async def register_page(req:Request): return render(req,"auth.html",mode="register",error=req.query_params.get("error"))
@app.post("/register")
async def register(email:str=Form(...),password:str=Form(...)):
    email=email.lower().strip()
    if not re.fullmatch(r"[^@\\s]+@[^@\\s]+\\.[^@\\s]+",email) or len(password)<10:return RedirectResponse("/register?error=Valid+email+and+10%2B+character+password+required",303)
    try:
        with connect() as c:c.execute("INSERT INTO users(email,password,role,created) VALUES(?,?,?,?)",(email,pw_hash(password),"user",now()));c.commit()
    except sqlite3.IntegrityError:return RedirectResponse("/register?error=Email+already+registered",303)
    return RedirectResponse("/login?error=Account+created,+please+login",303)
@app.post("/login")
async def login(req:Request,email:str=Form(...),password:str=Form(...)):
    with connect() as c:r=c.execute("SELECT * FROM users WHERE email=?",(email.lower().strip(),)).fetchone()
    if not r or not pw_ok(password,r["password"]):return RedirectResponse("/login?error=Invalid+credentials",303)
    req.session.clear();req.session["uid"]=r["id"];return RedirectResponse("/",303)
@app.post("/logout")
async def logout(req:Request):req.session.clear();return RedirectResponse("/login",303)

@app.post("/vps/create")
async def create(req:Request,name:str=Form(...),image:str=Form(...),cpu:int=Form(...),memory_gb:int=Form(...),disk_gb:int=Form(...)):
    u=need_user(req)
    if not re.fullmatch(r"[a-z][a-z0-9-]{2,23}",name):return RedirectResponse("/?error=Invalid+VPS+name",303)
    if image not in ("images:ubuntu/22.04","images:ubuntu/24.04","images:debian/12") or not(1<=cpu<=8 and 1<=memory_gb<=16 and 5<=disk_gb<=100):raise HTTPException(400,"Invalid OS or resource limits")
    with connect() as c:
        if c.execute("SELECT id FROM vps WHERE name=?",(name,)).fetchone():return RedirectResponse("/?error=VPS+name+already+exists",303)
        cur=c.execute("INSERT INTO vps(owner,name,image,cpu,ram,disk,status,created) VALUES(?,?,?,?,?,?,?,?)",(u["id"],name,image,cpu,memory_gb*1024,disk_gb,"creating",now()));vid=cur.lastrowid;c.commit()
    try:
        await node("POST","/instances",{"name":name,"image":image,"cpu":cpu,"memory_mb":memory_gb*1024,"disk_gb":disk_gb})
        status="running"
    except Exception as e:
        status="error";log(u["id"],"create_failed",f"{name}: {e}")
        with connect() as c:c.execute("UPDATE vps SET status=? WHERE id=?",("error",vid));c.commit()
        return RedirectResponse("/?error="+str(e).replace(" ","+")[:160],303)
    with connect() as c:c.execute("UPDATE vps SET status=? WHERE id=?", (status,vid));c.commit()
    log(u["id"],"create",name);return RedirectResponse("/",303)

async def owned(req,vid):
    u=need_user(req)
    with connect() as c:r=c.execute("SELECT * FROM vps WHERE id=?",(vid,)).fetchone()
    if not r:raise HTTPException(404,"VPS not found")
    if u["role"]!="admin" and r["owner"]!=u["id"]:raise HTTPException(403,"Forbidden")
    return u,dict(r)
@app.post("/vps/{vid}/{action}")
async def action(req:Request,vid:int,action:str):
    u,v=await owned(req,vid)
    if action not in ("start","stop","restart","reinstall","delete"):raise HTTPException(400,"Invalid action")
    try:
        if action=="delete":
            await node("DELETE",f"/instances/{v['name']}")
            with connect() as c:c.execute("DELETE FROM vps WHERE id=?",(vid,));c.commit()
        elif action=="reinstall":
            await node("POST",f"/instances/{v['name']}/reinstall",{"name":v["name"],"image":v["image"],"cpu":v["cpu"],"memory_mb":v["ram"],"disk_gb":v["disk"]})
            with connect() as c:c.execute("UPDATE vps SET status='running' WHERE id=?",(vid,));c.commit()
        else:
            await node("POST",f"/instances/{v['name']}/{action}")
            with connect() as c:c.execute("UPDATE vps SET status=? WHERE id=?",("running" if action in ("start","restart") else "stopped",vid));c.commit()
        log(u["id"],action,v["name"])
    except Exception as e:return RedirectResponse("/?error="+str(e).replace(" ","+")[:160],303)
    return RedirectResponse("/",303)

@app.get("/admin")
async def admin(req:Request):
    u=need_user(req)
    if u["role"]!="admin":raise HTTPException(403,"Admin only")
    with connect() as c:
        users=[dict(x) for x in c.execute("SELECT id,email,role,created FROM users ORDER BY id DESC")]
        logs=[dict(x) for x in c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 25")]
    return render(req,"admin.html",users=users,logs=logs)
@app.post("/admin/users/{uid}/role")
async def role(req:Request,uid:int,role:str=Form(...)):
    u=need_user(req)
    if u["role"]!="admin" or role not in ("user","admin") or uid==u["id"]:raise HTTPException(403,"Not allowed")
    with connect() as c:c.execute("UPDATE users SET role=? WHERE id=?",(role,uid));c.commit()
    log(u["id"],"role_change",f"{uid}:{role}");return RedirectResponse("/admin",303)
@app.get("/health")
async def health():return {"ok":True,"service":"zettanode-panel","node_configured":bool(NODE and TOKEN)}
