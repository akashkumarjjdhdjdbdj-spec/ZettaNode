#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "INSTALL FAILED at line $LINENO. Check the error above."; exit 1' ERR
if [[ $EUID -ne 0 ]]; then echo "Run: sudo bash install.sh"; exit 1; fi
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== ZettaNode Custom VPS Control — Panel Installer ==="
export DEBIAN_FRONTEND=noninteractive
HAS_SYSTEMD=0; [[ -d /run/systemd/system ]] && HAS_SYSTEMD=1
apt-get update
apt-get install -y python3 python3-venv python3-pip curl ca-certificates docker.io lxcfs xfsprogs
if (( HAS_SYSTEMD )); then systemctl enable --now lxcfs || echo "WARNING: lxcfs failed to start - free/nproc inside Docker VPS will show host values."; fi
if (( HAS_SYSTEMD )); then systemctl enable --now docker; else echo "WARNING: systemd not available - start the Docker daemon yourself (dockerd &)."; fi

# ── Optional: real disk size inside Docker VPS ──────────────────────────────
# Docker can only enforce a per-container disk size on XFS with the pquota option. If the host is ext4 (most are),
# we can put /var/lib/docker on a loop-mounted XFS image to get that.
FSTYPE="$(findmnt -no FSTYPE -T /var/lib/docker 2>/dev/null || true)"
if (( HAS_SYSTEMD )) && ! grep -q "docker-xfs.img" /etc/fstab && [[ "$FSTYPE" != "xfs" ]]; then
  echo
  echo "Disk quota for Docker VPS: without it, 'df -h' inside a Docker VPS shows the whole host disk."
  read -rp "Create XFS volume for Docker with quota support? Enter size in GB (e.g. 100) or press Enter to skip: " XFS_GB
  if [[ "$XFS_GB" =~ ^[0-9]+$ ]] && (( XFS_GB >= 20 )); then
    systemctl stop docker docker.socket
    [[ -d /var/lib/docker ]] && mv /var/lib/docker "/var/lib/docker.old.$(date +%s)"
    mkdir -p /var/lib/docker
    truncate -s "${XFS_GB}G" /var/lib/docker-xfs.img
    mkfs.xfs -f -q /var/lib/docker-xfs.img
    echo "/var/lib/docker-xfs.img /var/lib/docker xfs loop,pquota 0 0" >> /etc/fstab
    mount /var/lib/docker
    systemctl start docker
    echo "Docker now uses a ${XFS_GB} GB XFS volume with quota (old data kept in /var/lib/docker.old.*)."
  else
    echo "Skipped disk quota."
  fi
fi

python3 -m venv "$DIR/panel/.venv"
"$DIR/panel/.venv/bin/pip" install --upgrade pip
"$DIR/panel/.venv/bin/pip" install Flask gunicorn

# Keep existing secrets on re-run so the bot and sessions keep working
if [[ -f "$DIR/panel/.env" ]]; then
  echo "Existing panel/.env found — keeping it (delete it to reconfigure)."
  set -a; source "$DIR/panel/.env"; set +a
else
  SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  ZETTA_API_SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  read -rp "Panel admin username [admin]: " ADMIN_USER
  ADMIN_USER="${ADMIN_USER:-admin}"
  if [[ ! "$ADMIN_USER" =~ ^[A-Za-z][A-Za-z0-9_]{2,23}$ ]]; then
    echo "Admin username: 3-24 chars, start with a letter, only letters/numbers/underscore."; exit 1
  fi
  read -rsp "Panel admin password (min 12 chars): " ADMIN_PASS; echo
  if (( ${#ADMIN_PASS} < 12 )); then echo "Password must be at least 12 characters."; exit 1; fi
  read -rp "Public server IP/domain (used in SSH commands): " PUBLIC_HOST
  PUBLIC_HOST="${PUBLIC_HOST:-YOUR_SERVER_IP}"
  # the admin password is NOT written to .env (avoids quoting problems); it is hashed into the DB below
  umask 077
  cat > "$DIR/panel/.env" <<ENVEOF
SECRET_KEY=$SECRET_KEY
ZETTA_API_SECRET=$ZETTA_API_SECRET
ADMIN_USER=$ADMIN_USER
PUBLIC_HOST=$PUBLIC_HOST
PORT=8888
MAX_VPS_PER_USER=3
ENVEOF
  chmod 600 "$DIR/panel/.env"
  (cd "$DIR/panel" && ADMIN_PASS="$ADMIN_PASS" ADMIN_USER="$ADMIN_USER" SECRET_KEY="$SECRET_KEY" \
     ZETTA_API_SECRET="$ZETTA_API_SECRET" .venv/bin/python -c 'from app import init_db; init_db()')
fi

GUNICORN="$DIR/panel/.venv/bin/gunicorn -w 1 --threads 8 --timeout 900 -b 0.0.0.0:8888 app:app"
if (( HAS_SYSTEMD )); then
# 1 worker + threads: the in-process lock must serialise VPS creation; long timeout for docker pull 
cat > /etc/systemd/system/zettanode-panel.service <<SVCEOF
[Unit]
Description=ZettaNode Custom VPS Control Panel
After=network-online.target docker.service
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=$DIR/panel
EnvironmentFile=$DIR/panel/.env
ExecStart=$GUNICORN
Restart=on-failure
RestartSec=4
[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload
systemctl enable zettanode-panel
systemctl restart zettanode-panel
else
  echo "No systemd here. Start the panel manually with:"
  echo "  cd $DIR/panel && set -a && source .env && set +a && nohup $GUNICORN > panel.log 2>&1 &"
fi
echo
echo "Panel installed. Open: http://${PUBLIC_HOST:-SERVER_IP}:8888"
echo "Docker VPS SSH ports use 20000-29999 — open them in your firewall."
echo "API secret for bot (keep private): ${ZETTA_API_SECRET}"
echo "Optional: sudo bash tailscale.sh  puts the panel and all VPS on your private Tailscale network."
echo "Optional: sudo bash pterodactyl.sh  installs Pterodactyl Panel + Wings node on this server."
echo "Next: run  bash bot.sh  to configure and start the Discord bot."
echo "Note: Docker VPS need a host where the Docker daemon can run (a normal VPS/dedicated server)."
