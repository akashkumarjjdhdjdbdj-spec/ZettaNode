#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run: sudo bash install.sh"; exit 1; }
apt-get update
apt-get install -y python3 python3-venv python3-pip incus
install -d -m 0750 /opt/zettanode-node
cp agent.py requirements.txt /opt/zettanode-node/
python3 -m venv /opt/zettanode-node/venv
/opt/zettanode-node/venv/bin/pip install -r /opt/zettanode-node/requirements.txt
if [[ ! -f /opt/zettanode-node/.env ]]; then
 T="$(python3 -c 'import secrets;print(secrets.token_urlsafe(48))')"
 printf 'NODE_API_TOKEN=%s\\nNODE_BIND=127.0.0.1\\nNODE_PORT=8787\\n' "$T" > /opt/zettanode-node/.env
 chmod 600 /opt/zettanode-node/.env
fi
cat >/etc/systemd/system/zettanode-node.service <<'EOF'
[Unit]
Description=ZettaNode Incus Node Agent
After=network-online.target incus.service
Wants=network-online.target
[Service]
WorkingDirectory=/opt/zettanode-node
EnvironmentFile=/opt/zettanode-node/.env
ExecStart=/opt/zettanode-node/venv/bin/uvicorn agent:app --host ${NODE_BIND} --port ${NODE_PORT}
Restart=always
User=root
NoNewPrivileges=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now zettanode-node
echo "Node agent installed. Copy token from /opt/zettanode-node/.env securely."
echo "Default bind is localhost; configure HTTPS/private VPN before remote panel access."
