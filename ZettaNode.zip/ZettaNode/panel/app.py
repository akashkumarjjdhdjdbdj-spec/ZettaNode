import os, re, math, hmac, socket, sqlite3, subprocess, secrets, string, threading, time, shutil
from collections import defaultdict, deque
from contextlib import contextmanager
from pathlib import Path
from functools import wraps
from flask import (Flask, request, redirect, url_for, session, render_template,
                   flash, abort)
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = Path(__file__).resolve().parent


def _load_env_file():
    """Load panel/.env when running manually (systemd already injects it)."""
    f = APP_DIR / ".env"
    if not f.exists():
        return
    for line in f.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip("'\""))


_load_env_file()

DB = APP_DIR / "zettanode.db"
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_urlsafe(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1")
API_SECRET = os.environ.get("ZETTA_API_SECRET", "")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "")
PUBLIC_HOST = os.environ.get("PUBLIC_HOST", "YOUR_SERVER_IP")
MAX_VPS_PER_USER = int(os.environ.get("MAX_VPS_PER_USER", "3"))
PORT_RANGE = (20000, 29999)
LOCK = threading.Lock()
IMG_DIR = "/var/lib/libvirt/images"

def _cloud(fname, url):
    return {"file": f"{IMG_DIR}/{fname}", "url": url}


# group: shown in the panel dropdown. cloud=None -> Docker only (no official stable KVM cloud image).
# sudo_group: group cloud-init puts the user in. variant: libosinfo short-id (falls back to "generic").
OS_OPTIONS = {
    "ubuntu-24.04": {"label": "Ubuntu 24.04 LTS", "group": "Ubuntu", "docker": "ubuntu:24.04", "variant": "ubuntu24.04", "sudo_group": "sudo",
        "cloud": _cloud("ubuntu-24.04-server-cloudimg-amd64.img", "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img")},
    "ubuntu-22.04": {"label": "Ubuntu 22.04 LTS", "group": "Ubuntu", "docker": "ubuntu:22.04", "variant": "ubuntu22.04", "sudo_group": "sudo",
        "cloud": _cloud("ubuntu-22.04-server-cloudimg-amd64.img", "https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img")},
    "ubuntu-20.04": {"label": "Ubuntu 20.04 LTS", "group": "Ubuntu", "docker": "ubuntu:20.04", "variant": "ubuntu20.04", "sudo_group": "sudo",
        "cloud": _cloud("ubuntu-20.04-server-cloudimg-amd64.img", "https://cloud-images.ubuntu.com/focal/current/focal-server-cloudimg-amd64.img")},
    "debian-13": {"label": "Debian 13 (Trixie)", "group": "Debian", "docker": "debian:13", "variant": "debian13", "sudo_group": "sudo",
        "cloud": _cloud("debian-13-genericcloud-amd64.qcow2", "https://cloud.debian.org/images/cloud/trixie/latest/debian-13-genericcloud-amd64.qcow2")},
    "debian-12": {"label": "Debian 12 (Bookworm)", "group": "Debian", "docker": "debian:12", "variant": "debian12", "sudo_group": "sudo",
        "cloud": _cloud("debian-12-genericcloud-amd64.qcow2", "https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-genericcloud-amd64.qcow2")},
    "debian-11": {"label": "Debian 11 (Bullseye)", "group": "Debian", "docker": "debian:11", "variant": "debian11", "sudo_group": "sudo",
        "cloud": _cloud("debian-11-genericcloud-amd64.qcow2", "https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-genericcloud-amd64.qcow2")},
    "almalinux-9": {"label": "AlmaLinux 9", "group": "RHEL family", "docker": "almalinux:9", "variant": "almalinux9", "sudo_group": "wheel",
        "cloud": _cloud("almalinux-9-cloud.qcow2", "https://repo.almalinux.org/almalinux/9/cloud/x86_64/images/AlmaLinux-9-GenericCloud-latest.x86_64.qcow2")},
    "almalinux-8": {"label": "AlmaLinux 8", "group": "RHEL family", "docker": "almalinux:8", "variant": "almalinux8", "sudo_group": "wheel",
        "cloud": _cloud("almalinux-8-cloud.qcow2", "https://repo.almalinux.org/almalinux/8/cloud/x86_64/images/AlmaLinux-8-GenericCloud-latest.x86_64.qcow2")},
    "rocky-9": {"label": "Rocky Linux 9", "group": "RHEL family", "docker": "rockylinux:9", "variant": "rocky9", "sudo_group": "wheel",
        "cloud": _cloud("rocky-9-cloud.qcow2", "https://dl.rockylinux.org/pub/rocky/9/images/x86_64/Rocky-9-GenericCloud-Base.latest.x86_64.qcow2")},
    "rocky-8": {"label": "Rocky Linux 8", "group": "RHEL family", "docker": "rockylinux:8", "variant": "rocky8", "sudo_group": "wheel",
        "cloud": _cloud("rocky-8-cloud.qcow2", "https://dl.rockylinux.org/pub/rocky/8/images/x86_64/Rocky-8-GenericCloud-Base.latest.x86_64.qcow2")},
    "centos-stream-9": {"label": "CentOS Stream 9", "group": "RHEL family", "docker": "quay.io/centos/centos:stream9", "variant": "centos-stream9", "sudo_group": "wheel",
        "cloud": _cloud("centos-stream-9-cloud.qcow2", "https://cloud.centos.org/centos/9-stream/x86_64/images/CentOS-Stream-GenericCloud-9-latest.x86_64.qcow2")},
    "fedora-42": {"label": "Fedora 42", "group": "Other", "docker": "fedora:42", "variant": "fedora42", "sudo_group": "wheel", "cloud": None},
    "archlinux": {"label": "Arch Linux", "group": "Other", "docker": "archlinux:latest", "variant": "archlinux", "sudo_group": "wheel",
        "cloud": _cloud("archlinux-cloudimg.qcow2", "https://geo.mirror.pkgbuild.com/images/latest/Arch-Linux-x86_64-cloudimg.qcow2")},
    "alpine": {"label": "Alpine Linux (Docker only)", "group": "Other", "docker": "alpine:latest", "variant": "alpinelinux3.20", "sudo_group": "wheel", "cloud": None},
    "opensuse-leap": {"label": "openSUSE Leap 15.6 (Docker only)", "group": "Other", "docker": "opensuse/leap:15.6", "variant": "opensuse15.6", "sudo_group": "wheel", "cloud": None},
    "opensuse-tumbleweed": {"label": "openSUSE Tumbleweed (Docker only)", "group": "Other", "docker": "opensuse/tumbleweed", "variant": "opensusetumbleweed", "sudo_group": "wheel", "cloud": None},
    "kali": {"label": "Kali Linux (Docker only)", "group": "Other", "docker": "kalilinux/kali-rolling", "variant": "debian12", "sudo_group": "sudo", "cloud": None},
}
ACTIONS = {"start", "stop", "restart", "reinstall", "delete", "suspend", "unsuspend", "resetpass"}
RESERVED_USERS = {"root", "daemon", "bin", "sys", "sync", "games", "man", "lp", "mail", "news",
                  "uucp", "proxy", "www-data", "backup", "list", "irc", "nobody", "sshd"}


# ───────────────────────── database ─────────────────────────
@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _add_col(c, table, col, ddl):
    cols = {r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}
    if col not in cols:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")


def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user')""")
        c.execute("""CREATE TABLE IF NOT EXISTS vps(
            id INTEGER PRIMARY KEY, owner TEXT NOT NULL, name TEXT UNIQUE NOT NULL,
            kind TEXT NOT NULL, ram INTEGER NOT NULL, cpu REAL NOT NULL,
            disk INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'creating',
            password TEXT NOT NULL, node TEXT NOT NULL DEFAULT 'free',
            guest_username TEXT NOT NULL DEFAULT 'ubuntu',
            os_image TEXT NOT NULL DEFAULT 'ubuntu-24.04',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        _add_col(c, "vps", "node", "TEXT NOT NULL DEFAULT 'free'")
        _add_col(c, "vps", "guest_username", "TEXT NOT NULL DEFAULT 'ubuntu'")
        _add_col(c, "vps", "os_image", "TEXT NOT NULL DEFAULT 'ubuntu-24.04'")
        _add_col(c, "vps", "ssh_port", "INTEGER")
        _add_col(c, "vps", "ip", "TEXT")
        _add_col(c, "users", "discord_id", "TEXT")
        _add_col(c, "users", "link_code", "TEXT")
        _add_col(c, "users", "link_expires", "INTEGER")
        if ADMIN_PASS:
            c.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES(?,?,?)",
                      (ADMIN_USER, generate_password_hash(ADMIN_PASS), "admin"))


# ───────────────────────── helpers ─────────────────────────
def run(cmd, timeout=900, input=None):
    try:
        return subprocess.run(cmd, check=True, text=True, capture_output=True,
                              timeout=timeout, input=input)
    except subprocess.CalledProcessError as e:
        msg = (e.stderr or e.stdout or "").strip().splitlines()
        raise RuntimeError(f"{cmd[0]} failed: {' | '.join(msg[-3:]) or e.returncode}") from None
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{cmd[0]} timed out") from None
    except FileNotFoundError:
        raise RuntimeError(f"'{cmd[0]}' is not installed on this host") from None


def quiet(cmd, timeout=60):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception:
        return None


def hostname():
    chars = string.ascii_lowercase + string.digits
    with db() as c:
        while True:
            name = "ZettaNode-freevps-" + "".join(secrets.choice(chars) for _ in range(7))
            if not c.execute("SELECT 1 FROM vps WHERE name=?", (name,)).fetchone():
                return name


def clean_username(value):
    value = (value or "").strip().lower()
    if value in RESERVED_USERS or not re.fullmatch(r"[a-z_][a-z0-9_-]{1,23}", value):
        raise ValueError("VPS username: 2-24 chars, start with a letter/underscore, only a-z 0-9 _ - "
                         "(reserved names like root are not allowed).")
    return value


def parse_resources(ram, cpu, disk):
    try:
        ram, cpu, disk = int(ram), float(cpu), int(disk)
    except (TypeError, ValueError):
        raise ValueError("RAM, CPU and disk must be numbers.") from None
    if not (1 <= ram <= 32 and 0.25 <= cpu <= 16 and 5 <= disk <= 200):
        raise ValueError("Limits: RAM 1-32 GB, CPU 0.25-16, Disk 5-200 GB.")
    return ram, cpu, disk


def free_port():
    with db() as c:
        used = {r[0] for r in c.execute("SELECT ssh_port FROM vps WHERE ssh_port IS NOT NULL")}
    for _ in range(200):
        p = secrets.randbelow(PORT_RANGE[1] - PORT_RANGE[0]) + PORT_RANGE[0]
        if p in used:
            continue
        with socket.socket() as s:
            try:
                s.bind(("0.0.0.0", p))
            except OSError:
                continue
        return p
    raise RuntimeError("No free SSH port available.")


def kvm_ip(name):
    r = quiet(["virsh", "domifaddr", name, "--source", "lease"], 10)
    if r and r.returncode == 0:
        m = re.search(r"(\d+\.\d+\.\d+\.\d+)/", r.stdout)
        if m:
            return m.group(1)
    return None


# ───────────────────────── provisioning ─────────────────────────
DOCKER_BOOT = r'''set -e
if [ ! -f /var/lib/.zetta-ready ]; then
  export DEBIAN_FRONTEND=noninteractive
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq
    apt-get install -y -qq openssh-server sudo passwd ca-certificates >/dev/null
    apt-get install -y -qq curl nano >/dev/null 2>&1 || true
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y -q openssh-server sudo passwd shadow-utils
    dnf install -y -q nano curl >/dev/null 2>&1 || true
  elif command -v yum >/dev/null 2>&1; then
    yum install -y -q openssh-server sudo passwd shadow-utils
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache openssh sudo shadow bash
    apk add --no-cache nano curl >/dev/null 2>&1 || true
  elif command -v pacman >/dev/null 2>&1; then
    pacman -Sy --noconfirm --needed openssh sudo >/dev/null
  elif command -v zypper >/dev/null 2>&1; then
    zypper -n install --no-recommends openssh sudo shadow
  else
    echo "Unsupported package manager" >&2; exit 1
  fi
  id "$ZUSER" >/dev/null 2>&1 || useradd -m -s /bin/bash "$ZUSER"
  mkdir -p /etc/sudoers.d
  grep -q '^[#@]includedir /etc/sudoers.d' /etc/sudoers 2>/dev/null || echo '@includedir /etc/sudoers.d' >> /etc/sudoers
  echo "$ZUSER ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/90-zetta
  chmod 440 /etc/sudoers.d/90-zetta
  echo "$ZUSER:$ZPASS" | chpasswd
  ssh-keygen -A
  [ -f /etc/ssh/sshd_config ] || cp /usr/etc/ssh/sshd_config /etc/ssh/sshd_config 2>/dev/null || true
  sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  touch /var/lib/.zetta-ready
fi
mkdir -p /run/sshd /var/run/sshd
exec "$(command -v sshd || echo /usr/sbin/sshd)" -D -e
'''


def create_docker(name, ram, cpu, disk, password, username, os_image, port=None):
    image = OS_OPTIONS[os_image]["docker"]
    port = port or free_port()
    run(["docker", "pull", image])
    run(["docker", "run", "-d", "--name", name, "--hostname", name,
         "--memory", f"{ram}g", "--cpus", str(cpu), "--pids-limit", "512",
         "--restart", "unless-stopped", "-p", f"{port}:22",
         "-e", f"ZUSER={username}", "-e", f"ZPASS={password}",
         image, "sh", "-c", DOCKER_BOOT])
    return port


def ensure_cloud_image(cfg):
    """Download the KVM cloud image on first use (keeps install.sh fast)."""
    img = Path(cfg["cloud"]["file"])
    if not img.exists():
        part = img.with_name(img.name + ".part")
        run(["curl", "-fL", "--retry", "3", "-o", str(part), cfg["cloud"]["url"]], timeout=3600)
        part.rename(img)
    img.chmod(0o644)
    return img


def backing_virtual_gb(img):
    r = quiet(["qemu-img", "info", "--output=json", str(img)], 30)
    try:
        import json
        return math.ceil(json.loads(r.stdout)["virtual-size"] / 1024 ** 3)
    except Exception:
        return 0


def os_variant(short_id):
    r = quiet(["osinfo-query", "os", f"short-id={short_id}"], 15)
    return short_id if r and r.returncode == 0 and short_id in r.stdout else "generic"


def create_kvm(name, ram, cpu, disk, password, username, os_image):
    cfg = OS_OPTIONS[os_image]
    if not cfg["cloud"]:
        raise RuntimeError(f"{cfg['label']} has no KVM image - choose Docker VPS for this OS.")
    if not Path("/dev/kvm").exists():
        raise RuntimeError("KVM unavailable: /dev/kvm is missing on this host.")
    cloud_image = ensure_cloud_image(cfg)
    need = backing_virtual_gb(cloud_image)
    if disk < need:
        raise RuntimeError(f"{cfg['label']} needs at least {need} GB disk for KVM.")
    disk_path = f"{IMG_DIR}/{name}.qcow2"
    run(["qemu-img", "create", "-f", "qcow2", "-F", "qcow2", "-b", str(cloud_image), disk_path, f"{disk}G"])
    ci_dir = Path(IMG_DIR) / f"{name}-cloudinit"
    ci_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    user_data = ci_dir / "user-data"
    meta_data = ci_dir / "meta-data"
    user_data.write_text(
        "#cloud-config\n"
        "users:\n"
        f"  - name: {username}\n"
        f"    groups: [{cfg['sudo_group']}]\n"
        "    shell: /bin/bash\n"
        "    sudo: ['ALL=(ALL) NOPASSWD:ALL']\n"
        "    lock_passwd: false\n"
        f"    plain_text_passwd: '{password}'\n"
        "ssh_pwauth: true\n"
        "disable_root: true\n"
        "runcmd:\n"
        "  - [sh, -c, 'sed -i \"s/^#\\?PasswordAuthentication.*/PasswordAuthentication yes/\" "
        "/etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null; "
        "systemctl restart ssh 2>/dev/null || systemctl restart sshd']\n"
    )
    user_data.chmod(0o600)
    meta_data.write_text(f"instance-id: {name}\nlocal-hostname: {name}\n")
    run(["virt-install", "--name", name, "--memory", str(ram * 1024),
         "--vcpus", str(max(1, math.ceil(cpu))), "--import", "--os-variant", os_variant(cfg["variant"]),
         "--disk", f"path={disk_path},format=qcow2,bus=virtio",
         "--network", "network=default,model=virtio", "--graphics", "none",
         "--noautoconsole", "--cloud-init", f"user-data={user_data},meta-data={meta_data}"])
    return None


def cleanup(name, kind):
    """Best-effort removal of half-created resources."""
    if kind == "docker":
        quiet(["docker", "rm", "-f", name])
    else:
        quiet(["virsh", "destroy", name])
        quiet(["virsh", "undefine", name, "--remove-all-storage"])
        shutil.rmtree(Path(IMG_DIR) / f"{name}-cloudinit", ignore_errors=True)


def owned_count(owner):
    with db() as c:
        return c.execute("SELECT COUNT(*) FROM vps WHERE owner=?", (owner,)).fetchone()[0]


def create_vps(owner, kind, ram, cpu, disk, node, username, os_image, unlimited=False):
    username = clean_username(username)
    ram, cpu, disk = parse_resources(ram, cpu, disk)
    if kind not in ("docker", "kvm"):
        raise ValueError("Unknown VPS type.")
    if node not in ("free", "paid"):
        raise ValueError("Choose Free Node or Paid Node.")
    if os_image not in OS_OPTIONS:
        raise ValueError("Unsupported operating system.")
    if kind == "kvm" and not OS_OPTIONS[os_image]["cloud"]:
        raise ValueError(f"{OS_OPTIONS[os_image]['label']} is Docker-only. Pick Docker VPS or another OS for KVM.")
    with LOCK:
        if not unlimited and owned_count(owner) >= MAX_VPS_PER_USER:
            raise ValueError(f"VPS limit reached ({MAX_VPS_PER_USER} per user). Delete one first.")
        name = hostname()
        password = secrets.token_urlsafe(12)
        port = ip = None
        try:
            if kind == "docker":
                port = create_docker(name, ram, cpu, disk, password, username, os_image)
            else:
                create_kvm(name, ram, cpu, disk, password, username, os_image)
        except Exception:
            cleanup(name, kind)
            raise
        with db() as c:
            c.execute("""INSERT INTO vps(owner,name,kind,ram,cpu,disk,status,password,node,
                                         guest_username,os_image,ssh_port,ip)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (owner, name, kind, ram, cpu, disk, "running", password, node,
                       username, os_image, port, ip))
    return {"hostname": name, "username": username, "password": password, "status": "running",
            "node": node, "os": os_image, "kind": kind, "ssh_port": port,
            "ssh": ssh_cmd({"kind": kind, "guest_username": username, "ssh_port": port, "ip": ip})}


def ssh_cmd(v):
    if v["kind"] == "docker" and v["ssh_port"]:
        return f"ssh {v['guest_username']}@{PUBLIC_HOST} -p {v['ssh_port']}"
    if v["ip"]:
        return f"ssh {v['guest_username']}@{v['ip']}  (host-internal IP)"
    return "IP pending - press Sync"


def live_status(row):
    name = row["name"]
    cmd = (["docker", "inspect", "-f", "{{.State.Status}}", name] if row["kind"] == "docker"
           else ["virsh", "domstate", name])
    r = quiet(cmd, 10)
    if r is None:
        return row["status"]
    if r.returncode != 0:
        return "missing"
    state = "running" if r.stdout.strip() == "running" else "stopped"
    if state != "running" and row["status"] == "suspended":
        return "suspended"
    return state


def sync_rows(rows):
    with db() as c:
        for row in rows:
            st = live_status(row)
            ip = kvm_ip(row["name"]) if row["kind"] == "kvm" and st == "running" else row["ip"]
            c.execute("UPDATE vps SET status=?, ip=? WHERE id=?", (st, ip, row["id"]))


def control(row, action, new_password=None):
    name, kind = row["name"], row["kind"]
    port = row["ssh_port"]
    if kind == "docker":
        if action in ("start", "unsuspend"): run(["docker", "start", name])
        elif action in ("stop", "suspend"): run(["docker", "stop", name])
        elif action == "restart": run(["docker", "restart", name])
        elif action == "delete": run(["docker", "rm", "-f", name])
        elif action == "reinstall":
            quiet(["docker", "rm", "-f", name])
            create_docker(name, row["ram"], row["cpu"], row["disk"], row["password"],
                          row["guest_username"], row["os_image"], port=port)
        elif action == "resetpass":
            run(["docker", "exec", "-i", name, "chpasswd"],
                input=f"{row['guest_username']}:{new_password}\n", timeout=30)
    else:
        if action in ("start", "unsuspend"): run(["virsh", "start", name])
        elif action in ("stop", "suspend"): run(["virsh", "shutdown", name])
        elif action == "restart": run(["virsh", "reboot", name])
        elif action == "delete":
            cleanup(name, "kvm")
        elif action == "reinstall":
            cleanup(name, "kvm")
            create_kvm(name, row["ram"], row["cpu"], row["disk"], row["password"],
                       row["guest_username"], row["os_image"])
        elif action == "resetpass":
            raise RuntimeError("Password reset is only supported for Docker VPS. For KVM, reinstall the VPS.")
    status = {"delete": "deleted", "suspend": "suspended", "stop": "stopped"}.get(action, "running")
    with db() as c:
        if action == "delete":
            c.execute("DELETE FROM vps WHERE name=?", (name,))
        elif action == "resetpass":
            c.execute("UPDATE vps SET password=? WHERE name=?", (new_password, name))
        else:
            c.execute("UPDATE vps SET status=? WHERE name=?", (status, name))


def owner_ids(username):
    """Panel username + linked (verified) Discord ID."""
    ids = [username]
    with db() as c:
        r = c.execute("SELECT discord_id FROM users WHERE username=?", (username,)).fetchone()
    if r and r["discord_id"]:
        ids.append(r["discord_id"])
    return ids


def vps_for(ids):
    q = ",".join("?" * len(ids))
    with db() as c:
        return c.execute(f"SELECT * FROM vps WHERE owner IN ({q}) ORDER BY id DESC", ids).fetchall()


def row_dict(r):
    return {"name": r["name"], "kind": r["kind"], "status": r["status"], "node": r["node"],
            "os": r["os_image"], "username": r["guest_username"], "password": r["password"],
            "ram": r["ram"], "cpu": r["cpu"], "disk": r["disk"], "ssh": ssh_cmd(r)}


# ───────────────────────── security ─────────────────────────
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(24)
    return session["_csrf"]


app.jinja_env.globals.update(csrf_token=csrf_token, ssh_cmd=ssh_cmd, OS_OPTIONS=OS_OPTIONS,
                             MAX_VPS_PER_USER=MAX_VPS_PER_USER)


def safe_eq(a, b):
    return hmac.compare_digest(str(a).encode(), str(b).encode())


@app.before_request
def csrf_protect():
    if request.method == "POST" and not request.path.startswith("/api/bot/"):
        if not safe_eq(request.form.get("_csrf", ""), session.get("_csrf", "-")):
            abort(400, "CSRF check failed. Reload the page and try again.")


_attempts = defaultdict(deque)


def too_many_logins():
    now, q = time.time(), _attempts[request.remote_addr]
    while q and now - q[0] > 300:
        q.popleft()
    return len(q) >= 8


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if "username" not in session:
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if session.get("role") != "admin":
            abort(403)
        return fn(*a, **kw)
    return wrapper


def api_auth():
    return safe_eq(request.headers.get("X-Zetta-Secret", ""), API_SECRET) and bool(API_SECRET)


# ───────────────────────── web routes ─────────────────────────
@app.route("/")
@login_required
def index():
    rows = vps_for(owner_ids(session["username"]))
    stats = {"total": len(rows), "running": sum(r["status"] == "running" for r in rows),
             "ram": sum(r["ram"] for r in rows), "cpu": sum(r["cpu"] for r in rows),
             "disk": sum(r["disk"] for r in rows)}
    return render_template("index.html", rows=rows, stats=stats, username=session["username"])


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if too_many_logins():
            flash("Too many attempts. Try again in a few minutes.")
            return render_template("login.html", mode="Login"), 429
        with db() as c:
            u = c.execute("SELECT * FROM users WHERE username=?",
                          (request.form.get("username", "").strip(),)).fetchone()
        if u and check_password_hash(u["password"], request.form.get("password", "")):
            session.clear()
            session["username"], session["role"] = u["username"], u["role"]
            return redirect("/")
        _attempts[request.remote_addr].append(time.time())
        flash("Invalid username or password")
    return render_template("login.html", mode="Login")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{2,23}", username) or len(password) < 8:
            flash("Username: 3-24 chars, must start with a letter (letters/numbers/underscore). Password: 8+ characters.")
        else:
            try:
                with db() as c:
                    c.execute("INSERT INTO users(username,password) VALUES(?,?)",
                              (username, generate_password_hash(password)))
                flash("Account created. Please log in.")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username already exists.")
    return render_template("login.html", mode="Register")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/create", methods=["POST"])
@login_required
def create():
    try:
        f = request.form
        info = create_vps(session["username"], f.get("kind"), f.get("ram"), f.get("cpu"), f.get("disk"),
                          f.get("node"), f.get("guest_username"), f.get("os_image"),
                          unlimited=session.get("role") == "admin")
        flash(f"Created {info['hostname']} | user: {info['username']} | password: {info['password']} | {info['ssh']}")
    except Exception as e:
        flash(f"Create failed: {e}")
    return redirect("/")


@app.route("/action/<int:vps_id>/<action>", methods=["POST"])
@login_required
def action(vps_id, action):
    if action not in ACTIONS:
        flash("Invalid action.")
        return redirect(request.referrer or "/")
    with db() as c:
        row = c.execute("SELECT * FROM vps WHERE id=?", (vps_id,)).fetchone()
    if not row or (session.get("role") != "admin" and row["owner"] not in owner_ids(session["username"])):
        flash("VPS not found.")
        return redirect("/")
    try:
        newpass = secrets.token_urlsafe(12) if action == "resetpass" else None
        control(row, action, newpass)
        flash(f"New password for {row['name']}: {newpass}" if newpass
              else f"{action.title()} completed for {row['name']}.")
    except Exception as e:
        flash(f"Action failed: {e}")
    return redirect(request.referrer or "/")


@app.route("/sync", methods=["POST"])
@login_required
def sync():
    rows = vps_for(owner_ids(session["username"]))
    if session.get("role") == "admin" and request.form.get("all"):
        with db() as c:
            rows = c.execute("SELECT * FROM vps").fetchall()
    sync_rows(rows)
    flash("Status synced.")
    return redirect(request.referrer or "/")


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    me = session["username"]
    if request.method == "POST":
        what = request.form.get("what")
        with db() as c:
            if what == "linkcode":
                code = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
                c.execute("UPDATE users SET link_code=?, link_expires=? WHERE username=?",
                          (code, int(time.time()) + 600, me))
                flash("Link code generated. In Discord run /link and paste it within 10 minutes.")
            elif what == "unlink":
                c.execute("UPDATE users SET discord_id=NULL WHERE username=?", (me,))
                flash("Discord account unlinked.")
            elif what == "password":
                u = c.execute("SELECT * FROM users WHERE username=?", (me,)).fetchone()
                new = request.form.get("new_password", "")
                if not check_password_hash(u["password"], request.form.get("old_password", "")):
                    flash("Current password is wrong.")
                elif len(new) < 8:
                    flash("New password must be at least 8 characters.")
                else:
                    c.execute("UPDATE users SET password=? WHERE username=?", (generate_password_hash(new), me))
                    flash("Password changed.")
        return redirect(url_for("profile"))
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE username=?", (me,)).fetchone()
    code = u["link_code"] if u["link_code"] and (u["link_expires"] or 0) > time.time() else None
    return render_template("profile.html", u=u, code=code, username=me)


@app.route("/admin")
@admin_required
def admin():
    with db() as c:
        rows = c.execute("SELECT * FROM vps ORDER BY id DESC").fetchall()
        users = c.execute("SELECT id,username,role,discord_id FROM users ORDER BY id").fetchall()
    return render_template("admin.html", rows=rows, users=users, username=session["username"])


# ───────────────────────── bot API ─────────────────────────
def _bot_json():
    if not api_auth():
        abort(401)
    return request.get_json(force=True, silent=True) or {}


@app.errorhandler(401)
def _e401(e):
    return ({"error": "Unauthorized"}, 401) if request.path.startswith("/api/") else ("Unauthorized", 401)


@app.post("/api/bot/create")
def bot_create():
    d = _bot_json()
    owner = str(d.get("owner", "")).strip()
    if not owner:
        return {"error": "Missing owner"}, 400
    try:
        return create_vps(owner, d.get("kind", "docker"), d.get("ram", 1), d.get("cpu", 1), d.get("disk", 10),
                          d.get("node", "free"), d.get("username", "ubuntu"), d.get("os", "ubuntu-24.04"))
    except ValueError as e:
        return {"error": str(e)}, 400
    except Exception as e:
        return {"error": str(e)}, 500


def _bot_owner_ids(owner):
    ids = [owner]
    with db() as c:
        r = c.execute("SELECT username FROM users WHERE discord_id=?", (owner,)).fetchone()
    if r:
        ids.append(r["username"])
    return ids


def _bot_row(d):
    ids = _bot_owner_ids(str(d.get("owner", "")))
    q = ",".join("?" * len(ids))
    with db() as c:
        return c.execute(f"SELECT * FROM vps WHERE name=? AND owner IN ({q})",
                         [d.get("hostname"), *ids]).fetchone()


@app.post("/api/bot/list")
def bot_list():
    d = _bot_json()
    rows = vps_for(_bot_owner_ids(str(d.get("owner", ""))))
    if d.get("sync"):
        sync_rows(rows)
        rows = vps_for(_bot_owner_ids(str(d.get("owner", ""))))
    return {"vps": [row_dict(r) for r in rows]}


@app.post("/api/bot/info")
def bot_info():
    d = _bot_json()
    row = _bot_row(d)
    if not row:
        return {"error": "VPS not found for this owner"}, 404
    sync_rows([row])
    return row_dict(_bot_row(d))


@app.post("/api/bot/action")
def bot_action():
    d = _bot_json()
    row = _bot_row(d)
    if not row:
        return {"error": "VPS not found for this owner"}, 404
    action = d.get("action")
    if action not in ACTIONS:
        return {"error": "Invalid action"}, 400
    try:
        newpass = secrets.token_urlsafe(12) if action == "resetpass" else None
        control(row, action, newpass)
        return {"ok": True, "password": newpass}
    except Exception as e:
        return {"error": str(e)}, 500


@app.post("/api/bot/link")
def bot_link():
    d = _bot_json()
    owner, code = str(d.get("owner", "")).strip(), str(d.get("code", "")).strip().upper()
    if not owner or not code:
        return {"error": "Missing owner or code"}, 400
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE link_code=? AND link_expires>?", (code, int(time.time()))).fetchone()
        if not u:
            return {"error": "Invalid or expired code. Generate a new one in the panel (Profile page)."}, 400
        if c.execute("SELECT 1 FROM users WHERE discord_id=? AND id!=?", (owner, u["id"])).fetchone():
            return {"error": "This Discord account is already linked to another panel user."}, 400
        c.execute("UPDATE users SET discord_id=?, link_code=NULL, link_expires=NULL WHERE id=?", (owner, u["id"]))
    return {"ok": True, "username": u["username"]}


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8888")))
