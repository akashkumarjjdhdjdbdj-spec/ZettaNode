#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "INSTALL FAILED at line $LINENO. Check the error above."; exit 1' ERR
if [[ $EUID -ne 0 ]]; then echo "Run: sudo bash install.sh"; exit 1; fi
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== ZettaNode Custom VPS Control — Panel Installer ==="
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip curl ca-certificates \
  docker.io qemu-kvm libvirt-daemon-system libvirt-clients virtinst \
  qemu-utils cloud-image-utils genisoimage libosinfo-bin
systemctl enable --now docker
systemctl enable --now libvirtd || systemctl enable --now libvirt
if [[ ! -e /dev/kvm ]]; then
  echo "WARNING: /dev/kvm not found. Docker VPS can work; KVM VPS creation will fail on this host."
fi
# Only the 3 most common KVM images are pre-downloaded; every other OS image is fetched automatically on first use.
# libvirt default NAT network must exist and be running for KVM guests
virsh net-autostart default >/dev/null 2>&1 || true
virsh net-start default >/dev/null 2>&1 || true

IMG=/var/lib/libvirt/images
mkdir -p "$IMG"
fetch() { # fetch <file> <url>
  if [[ ! -f "$IMG/$1" ]]; then curl -fL --retry 3 "$2" -o "$IMG/$1.part" && mv "$IMG/$1.part" "$IMG/$1"; fi
  chmod 644 "$IMG/$1"
}
fetch ubuntu-24.04-server-cloudimg-amd64.img https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img
fetch ubuntu-22.04-server-cloudimg-amd64.img https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img
fetch debian-12-genericcloud-amd64.qcow2 https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-genericcloud-amd64.qcow2

python3 -m venv "$DIR/panel/.venv"
"$DIR/panel/.venv/bin/pip" install --upgrade pip
"$DIR/panel/.venv/bin/pip" install Flask gunicorn

# Keep existing secrets on re-run so the bot and sessions keep working
if [[ -f "$DIR/panel/.env" ]]; then
  echo "Existing panel/.env found — keeping it (delete it to reconfigure)."
  set -a; source "$DIR/panel/.env"; set +a
else
  SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  ZETTA_API_SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  read -rp "Panel admin username [admin]: " ADMIN_USER
  ADMIN_USER="${ADMIN_USER:-admin}"
  if [[ ! "$ADMIN_USER" =~ ^[A-Za-z][A-Za-z0-9_]{2,23}$ ]]; then
    echo "Admin username: 3-24 chars, start with a letter, only letters/numbers/underscore."; exit 1
  fi
  read -rsp "Panel admin password (min 12 chars): " ADMIN_PASS; echo
  if (( ${#ADMIN_PASS} < 12 )); then echo "Password must be at least 12 characters."; exit 1; fi
  read -rp "Public server IP/domain (used in SSH commands): " PUBLIC_HOST
  PUBLIC_HOST="${PUBLIC_HOST:-YOUR_SERVER_IP}"
  # the admin password is NOT written to .env (avoids quoting problems); it is hashed into the DB below
  umask 077
  cat > "$DIR/panel/.env" <<ENVEOF
SECRET_KEY=$SECRET_KEY
ZETTA_API_SECRET=$ZETTA_API_SECRET
ADMIN_USER=$ADMIN_USER
PUBLIC_HOST=$PUBLIC_HOST
PORT=8888
MAX_VPS_PER_USER=3
ENVEOF
  chmod 600 "$DIR/panel/.env"
  (cd "$DIR/panel" && ADMIN_PASS="$ADMIN_PASS" ADMIN_USER="$ADMIN_USER" SECRET_KEY="$SECRET_KEY" \
     ZETTA_API_SECRET="$ZETTA_API_SECRET" .venv/bin/python -c 'from app import init_db; init_db()')
fi

# 1 worker + threads: the in-process lock must serialise VPS creation; long timeout for docker pull / KVM create
cat > /etc/systemd/system/zettanode-panel.service <<SVCEOF
[Unit]
Description=ZettaNode Custom VPS Control Panel
After=network-online.target docker.service libvirtd.service
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=$DIR/panel
EnvironmentFile=$DIR/panel/.env
ExecStart=$DIR/panel/.venv/bin/gunicorn -w 1 --threads 8 --timeout 900 -b 0.0.0.0:8888 app:app
Restart=on-failure
RestartSec=4
[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload
systemctl enable zettanode-panel
systemctl restart zettanode-panel
echo
echo "Panel installed. Open: http://${PUBLIC_HOST:-SERVER_IP}:8888"
echo "Docker VPS SSH ports use 20000-29999 — open them in your firewall."
echo "API secret for bot (keep private): ${ZETTA_API_SECRET}"
echo "Next: run  bash bot.sh  to configure and start the Discord bot."
echo "Note: KVM requires a real KVM-enabled Ubuntu host. Railway cannot provide /dev/kvm."
